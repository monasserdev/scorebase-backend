"use strict";
/**
 * Player Models
 *
 * Type definitions for players and related entities.
 * Players represent individual athletes on teams.
 *
 * Requirements: 4.3, 4.4
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapPlayerRow = mapPlayerRow;
/**
 * Convert database row to Player model
 */
function mapPlayerRow(row) {
    return {
        id: row.id,
        team_id: row.team_id,
        first_name: row.first_name,
        last_name: row.last_name,
        jersey_number: row.jersey_number || undefined,
        position: row.position || undefined,
        created_at: row.created_at,
        updated_at: row.updated_at,
    };
}
//# sourceMappingURL=player.js.map