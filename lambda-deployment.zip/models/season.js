"use strict";
/**
 * Season Models
 *
 * Type definitions for seasons and related entities.
 * Seasons represent time-bound competition periods within a league.
 *
 * Requirements: 3.3, 3.4
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapSeasonRow = mapSeasonRow;
/**
 * Convert database row to Season model
 */
function mapSeasonRow(row) {
    return {
        id: row.id,
        league_id: row.league_id,
        name: row.name,
        start_date: row.start_date,
        end_date: row.end_date,
        is_active: row.is_active,
        created_at: row.created_at,
        updated_at: row.updated_at,
    };
}
//# sourceMappingURL=season.js.map