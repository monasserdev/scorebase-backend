/**
 * Standing Models
 *
 * Type definitions for team standings and related entities.
 * Standings represent calculated team rankings within a season.
 *
 * Requirements: 7.1, 7.9, 7.10
 */
/**
 * Team standing entity from database
 */
export interface TeamStanding {
    id: string;
    season_id: string;
    team_id: string;
    games_played: number;
    wins: number;
    losses: number;
    ties: number;
    points: number;
    goals_for: number;
    goals_against: number;
    goal_differential: number;
    streak?: string;
    created_at: Date;
    updated_at: Date;
}
/**
 * Standing database row (matches PostgreSQL schema)
 */
export interface StandingRow {
    id: string;
    season_id: string;
    team_id: string;
    games_played: number;
    wins: number;
    losses: number;
    ties: number;
    points: number;
    goals_for: number;
    goals_against: number;
    goal_differential: number;
    streak: string | null;
    created_at: Date;
    updated_at: Date;
}
/**
 * Convert database row to TeamStanding model
 */
export declare function mapStandingRow(row: StandingRow): TeamStanding;
/**
 * Standing data for upsert operations
 */
export interface StandingUpsertData {
    season_id: string;
    team_id: string;
    games_played: number;
    wins: number;
    losses: number;
    ties: number;
    points: number;
    goals_for: number;
    goals_against: number;
    goal_differential: number;
    streak?: string;
}
//# sourceMappingURL=standing.d.ts.map