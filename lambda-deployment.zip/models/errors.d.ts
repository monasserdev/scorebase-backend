/**
 * Application Error Models
 *
 * Common error types used across the application.
 * These errors are mapped to appropriate HTTP status codes
 * by the error handling middleware.
 *
 * Requirements: 8.5, 8.6, 8.7, 8.8
 */
/**
 * Resource not found error (404)
 */
export declare class NotFoundError extends Error {
    constructor(message: string);
}
/**
 * Bad request error (400)
 */
export declare class BadRequestError extends Error {
    constructor(message: string);
}
/**
 * Forbidden error (403)
 */
export declare class ForbiddenError extends Error {
    constructor(message: string);
}
/**
 * Service unavailable error (503)
 */
export declare class ServiceUnavailableError extends Error {
    constructor(message: string);
}
//# sourceMappingURL=errors.d.ts.map