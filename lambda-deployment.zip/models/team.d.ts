/**
 * Team Models
 *
 * Type definitions for teams and related entities.
 * Teams represent competing entities within a league.
 *
 * Requirements: 4.1, 4.2
 */
/**
 * Team entity from database
 */
export interface Team {
    id: string;
    tenant_id: string;
    league_id: string;
    name: string;
    abbreviation?: string;
    logo_url?: string;
    primary_color?: string;
    secondary_color?: string;
    created_at: Date;
    updated_at: Date;
}
/**
 * Team database row (matches PostgreSQL schema)
 */
export interface TeamRow {
    id: string;
    tenant_id: string;
    league_id: string;
    name: string;
    abbreviation: string | null;
    logo_url: string | null;
    primary_color: string | null;
    secondary_color: string | null;
    created_at: Date;
    updated_at: Date;
}
/**
 * Convert database row to Team model
 */
export declare function mapTeamRow(row: TeamRow): Team;
//# sourceMappingURL=team.d.ts.map