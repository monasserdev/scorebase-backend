"use strict";
/**
 * Team Models
 *
 * Type definitions for teams and related entities.
 * Teams represent competing entities within a league.
 *
 * Requirements: 4.1, 4.2
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapTeamRow = mapTeamRow;
/**
 * Convert database row to Team model
 */
function mapTeamRow(row) {
    return {
        id: row.id,
        tenant_id: row.tenant_id,
        league_id: row.league_id,
        name: row.name,
        abbreviation: row.abbreviation || undefined,
        logo_url: row.logo_url || undefined,
        primary_color: row.primary_color || undefined,
        secondary_color: row.secondary_color || undefined,
        created_at: row.created_at,
        updated_at: row.updated_at,
    };
}
//# sourceMappingURL=team.js.map