/**
 * League Models
 *
 * Type definitions for leagues and related entities.
 * Leagues represent sport competitions within a tenant.
 *
 * Requirements: 3.1, 3.2
 */
/**
 * Supported sport types
 */
export declare enum SportType {
    BASKETBALL = "basketball",
    SOCCER = "soccer",
    HOCKEY = "hockey",
    BASEBALL = "baseball",
    FOOTBALL = "football"
}
/**
 * League entity from database
 */
export interface League {
    id: string;
    tenant_id: string;
    name: string;
    sport_type: SportType;
    logo_url?: string;
    primary_color?: string;
    secondary_color?: string;
    created_at: Date;
    updated_at: Date;
}
/**
 * League database row (matches PostgreSQL schema)
 */
export interface LeagueRow {
    id: string;
    tenant_id: string;
    name: string;
    sport_type: string;
    logo_url: string | null;
    primary_color: string | null;
    secondary_color: string | null;
    created_at: Date;
    updated_at: Date;
}
/**
 * Convert database row to League model
 */
export declare function mapLeagueRow(row: LeagueRow): League;
//# sourceMappingURL=league.d.ts.map