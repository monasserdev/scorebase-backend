"use strict";
/**
 * Standing Models
 *
 * Type definitions for team standings and related entities.
 * Standings represent calculated team rankings within a season.
 *
 * Requirements: 7.1, 7.9, 7.10
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapStandingRow = mapStandingRow;
/**
 * Convert database row to TeamStanding model
 */
function mapStandingRow(row) {
    return {
        id: row.id,
        season_id: row.season_id,
        team_id: row.team_id,
        games_played: row.games_played,
        wins: row.wins,
        losses: row.losses,
        ties: row.ties,
        points: row.points,
        goals_for: row.goals_for,
        goals_against: row.goals_against,
        goal_differential: row.goal_differential,
        streak: row.streak || undefined,
        created_at: row.created_at,
        updated_at: row.updated_at,
    };
}
//# sourceMappingURL=standing.js.map