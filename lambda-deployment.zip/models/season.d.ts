/**
 * Season Models
 *
 * Type definitions for seasons and related entities.
 * Seasons represent time-bound competition periods within a league.
 *
 * Requirements: 3.3, 3.4
 */
/**
 * Season entity from database
 */
export interface Season {
    id: string;
    league_id: string;
    name: string;
    start_date: Date;
    end_date: Date;
    is_active: boolean;
    created_at: Date;
    updated_at: Date;
}
/**
 * Season database row (matches PostgreSQL schema)
 */
export interface SeasonRow {
    id: string;
    league_id: string;
    name: string;
    start_date: Date;
    end_date: Date;
    is_active: boolean;
    created_at: Date;
    updated_at: Date;
}
/**
 * Convert database row to Season model
 */
export declare function mapSeasonRow(row: SeasonRow): Season;
//# sourceMappingURL=season.d.ts.map