"use strict";
/**
 * Application Error Models
 *
 * Common error types used across the application.
 * These errors are mapped to appropriate HTTP status codes
 * by the error handling middleware.
 *
 * Requirements: 8.5, 8.6, 8.7, 8.8
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceUnavailableError = exports.ForbiddenError = exports.BadRequestError = exports.NotFoundError = void 0;
/**
 * Resource not found error (404)
 */
class NotFoundError extends Error {
    constructor(message) {
        super(message);
        this.name = 'NotFoundError';
    }
}
exports.NotFoundError = NotFoundError;
/**
 * Bad request error (400)
 */
class BadRequestError extends Error {
    constructor(message) {
        super(message);
        this.name = 'BadRequestError';
    }
}
exports.BadRequestError = BadRequestError;
/**
 * Forbidden error (403)
 */
class ForbiddenError extends Error {
    constructor(message) {
        super(message);
        this.name = 'ForbiddenError';
    }
}
exports.ForbiddenError = ForbiddenError;
/**
 * Service unavailable error (503)
 */
class ServiceUnavailableError extends Error {
    constructor(message) {
        super(message);
        this.name = 'ServiceUnavailableError';
    }
}
exports.ServiceUnavailableError = ServiceUnavailableError;
//# sourceMappingURL=errors.js.map