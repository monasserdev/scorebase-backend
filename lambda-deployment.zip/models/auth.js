"use strict";
/**
 * Authentication Models
 *
 * Type definitions for JWT tokens and authentication context.
 *
 * Requirements: 1.1, 1.2, 1.3, 1.4
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthError = exports.AuthErrorCode = void 0;
/**
 * Authentication error types
 */
var AuthErrorCode;
(function (AuthErrorCode) {
    AuthErrorCode["MISSING_TOKEN"] = "MISSING_TOKEN";
    AuthErrorCode["INVALID_TOKEN"] = "INVALID_TOKEN";
    AuthErrorCode["EXPIRED_TOKEN"] = "EXPIRED_TOKEN";
    AuthErrorCode["INVALID_SIGNATURE"] = "INVALID_SIGNATURE";
    AuthErrorCode["MISSING_TENANT_ID"] = "MISSING_TENANT_ID";
})(AuthErrorCode || (exports.AuthErrorCode = AuthErrorCode = {}));
/**
 * Authentication error
 */
class AuthError extends Error {
    constructor(code, message) {
        super(message);
        this.code = code;
        this.name = 'AuthError';
    }
}
exports.AuthError = AuthError;
//# sourceMappingURL=auth.js.map