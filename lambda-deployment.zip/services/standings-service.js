"use strict";
/**
 * Standings Service
 *
 * Business logic layer for standings operations.
 * Handles standings retrieval with proper error handling.
 *
 * Requirements: 7.9, 14.13
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.StandingsService = void 0;
/**
 * Standings Service
 * Provides business logic for standings operations
 */
class StandingsService {
    constructor(standingsRepository) {
        this.standingsRepository = standingsRepository;
    }
    /**
     * Get standings for a season ordered by points DESC
     *
     * Returns standings ordered by:
     * 1. points DESC (primary sort)
     * 2. goal_differential DESC (tiebreaker)
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param seasonId - Season identifier
     * @returns Array of standings ordered by points DESC, goal_differential DESC
     */
    async getStandingsBySeason(tenantId, seasonId) {
        return this.standingsRepository.findBySeasonId(tenantId, seasonId);
    }
}
exports.StandingsService = StandingsService;
//# sourceMappingURL=standings-service.js.map