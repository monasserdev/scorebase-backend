/**
 * Team Service
 *
 * Business logic layer for team operations.
 * Handles team retrieval with proper error handling.
 *
 * Requirements: 4.1, 4.2, 14.5, 14.6
 */
import { TeamRepository } from '../repositories/team-repository';
import { Team } from '../models/team';
/**
 * Team Service
 * Provides business logic for team operations
 */
export declare class TeamService {
    private teamRepository;
    constructor(teamRepository: TeamRepository);
    /**
     * Get all teams for a league
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param leagueId - League identifier
     * @returns Array of teams belonging to the league
     */
    getTeamsByLeague(tenantId: string, leagueId: string): Promise<Team[]>;
    /**
     * Get a team by ID with 404 handling
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param teamId - Team identifier
     * @returns Team if found and belongs to tenant
     * @throws NotFoundError if team doesn't exist or doesn't belong to tenant
     */
    getTeamById(tenantId: string, teamId: string): Promise<Team>;
}
//# sourceMappingURL=team-service.d.ts.map