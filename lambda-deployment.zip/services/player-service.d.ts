/**
 * Player Service
 *
 * Business logic layer for player operations.
 * Handles player retrieval with proper error handling.
 *
 * Requirements: 4.3, 4.4, 14.7, 14.8
 */
import { PlayerRepository } from '../repositories/player-repository';
import { Player } from '../models/player';
/**
 * Player Service
 * Provides business logic for player operations
 */
export declare class PlayerService {
    private playerRepository;
    constructor(playerRepository: PlayerRepository);
    /**
     * Get all players for a team
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param teamId - Team identifier
     * @returns Array of players belonging to the team
     */
    getPlayersByTeam(tenantId: string, teamId: string): Promise<Player[]>;
    /**
     * Get a player by ID with 404 handling
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param playerId - Player identifier
     * @returns Player if found and belongs to tenant
     * @throws NotFoundError if player doesn't exist or doesn't belong to tenant
     */
    getPlayerById(tenantId: string, playerId: string): Promise<Player>;
}
//# sourceMappingURL=player-service.d.ts.map