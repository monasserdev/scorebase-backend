"use strict";
/**
 * Season Service
 *
 * Business logic layer for season operations.
 * Handles season retrieval with proper error handling.
 *
 * Requirements: 3.3, 3.4, 14.3, 14.4
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeasonService = void 0;
const errors_1 = require("../models/errors");
/**
 * Season Service
 * Provides business logic for season operations
 */
class SeasonService {
    constructor(seasonRepository) {
        this.seasonRepository = seasonRepository;
    }
    /**
     * Get all seasons for a league
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param leagueId - League identifier
     * @returns Array of seasons belonging to the league
     */
    async getSeasonsByLeague(tenantId, leagueId) {
        return this.seasonRepository.findByLeagueId(tenantId, leagueId);
    }
    /**
     * Get a season by ID with 404 handling
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param seasonId - Season identifier
     * @returns Season if found and belongs to tenant
     * @throws NotFoundError if season doesn't exist or doesn't belong to tenant
     */
    async getSeasonById(tenantId, seasonId) {
        const season = await this.seasonRepository.findById(tenantId, seasonId);
        if (!season) {
            throw new errors_1.NotFoundError('Season not found');
        }
        return season;
    }
}
exports.SeasonService = SeasonService;
//# sourceMappingURL=season-service.js.map