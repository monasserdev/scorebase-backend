/**
 * Event Service
 *
 * Business logic layer for event operations.
 * Handles event creation with validation, persistence to DynamoDB,
 * and game state updates in RDS.
 *
 * Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.7, 6.8, 6.9, 14.11, 14.12
 */
import { GameRepository } from '../repositories/game-repository';
import { SeasonRepository } from '../repositories/season-repository';
import { TeamRepository } from '../repositories/team-repository';
import { StandingsRepository } from '../repositories/standings-repository';
import { GameEvent, EventType, EventMetadata } from '../models/event';
/**
 * Event Service
 * Provides business logic for event operations
 */
export declare class EventService {
    private gameRepository;
    private seasonRepository;
    private teamRepository;
    private standingsRepository;
    constructor(gameRepository: GameRepository, seasonRepository: SeasonRepository, teamRepository: TeamRepository, standingsRepository: StandingsRepository);
    /**
     * Get all events for a game in chronological order
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param gameId - Game identifier
     * @returns Array of events in chronological order
     * @throws NotFoundError if game doesn't exist or doesn't belong to tenant
     */
    getEventsByGame(tenantId: string, gameId: string): Promise<GameEvent[]>;
    /**
     * Create a new event with validation and persistence
     *
     * This method:
     * 1. Validates game exists and belongs to tenant
     * 2. Prevents event creation for finalized games
     * 3. Validates event payload against event_type schema
     * 4. Writes event to DynamoDB with TTL
     * 5. Applies event to game state in RDS
     * 6. Triggers standings recalculation for GAME_FINALIZED events
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param gameId - Game identifier
     * @param eventType - Type of event to create
     * @param payload - Event-specific payload data
     * @param metadata - Event metadata (user_id, source, etc.)
     * @returns Created event with event_id
     * @throws NotFoundError if game doesn't exist or doesn't belong to tenant
     * @throws BadRequestError if game is finalized or payload is invalid
     */
    createEvent(tenantId: string, gameId: string, eventType: EventType, payload: any, metadata: EventMetadata): Promise<GameEvent>;
}
//# sourceMappingURL=event-service.d.ts.map