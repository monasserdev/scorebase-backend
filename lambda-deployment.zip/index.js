"use strict";
/**
 * ScoreBase Backend API
 *
 * Main entry point for the Lambda function.
 * This file will be implemented in later tasks.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
__exportStar(require("./config/environment"), exports);
__exportStar(require("./config/database"), exports);
__exportStar(require("./config/dynamodb"), exports);
__exportStar(require("./models/event"), exports);
// Placeholder for Lambda handler
// Will be implemented in task 9.1
async function handler(_event) {
    return {
        statusCode: 200,
        body: JSON.stringify({
            message: 'ScoreBase Backend API - Coming Soon',
        }),
    };
}
//# sourceMappingURL=index.js.map