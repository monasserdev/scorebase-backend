/**
 * Multi-Tenant Isolation Middleware
 *
 * Enforces strict tenant isolation at the database query level.
 * Validates that all queries include tenant_id filtering and verifies
 * that all results belong to the requesting tenant.
 *
 * Requirements: 2.1, 2.2, 2.3, 2.4, 2.5
 */
import { QueryResult, QueryResultRow } from 'pg';
/**
 * Multi-tenant isolation error types
 */
export declare enum TenantIsolationErrorCode {
    INVALID_TENANT_ID = "INVALID_TENANT_ID",
    QUERY_MISSING_TENANT_FILTER = "QUERY_MISSING_TENANT_FILTER",
    TENANT_ISOLATION_VIOLATION = "TENANT_ISOLATION_VIOLATION"
}
/**
 * Multi-tenant isolation error
 */
export declare class TenantIsolationError extends Error {
    code: TenantIsolationErrorCode;
    details?: any | undefined;
    constructor(code: TenantIsolationErrorCode, message: string, details?: any | undefined);
}
/**
 * Enforce multi-tenant isolation query wrapper
 *
 * This function wraps database queries to ensure:
 * 1. tenant_id is present and valid
 * 2. Query includes tenant_id filter in WHERE clause
 * 3. All results belong to the requesting tenant
 * 4. Security violations are logged to CloudWatch
 *
 * @param tenantId - Tenant identifier from JWT claims
 * @param queryText - SQL query with $1 placeholder for tenant_id
 * @param params - Additional query parameters (tenant_id will be prepended)
 * @returns Query result with tenant isolation enforced
 * @throws TenantIsolationError for isolation violations
 */
export declare function enforceMultiTenantIsolation<T extends QueryResultRow = any>(tenantId: string, queryText: string, params?: any[]): Promise<QueryResult<T>>;
/**
 * Convenience wrapper for queries that return a single row
 * Returns null if no row found
 */
export declare function enforceMultiTenantIsolationSingle<T extends QueryResultRow = any>(tenantId: string, queryText: string, params?: any[]): Promise<T | null>;
/**
 * Convenience wrapper for queries that return multiple rows
 * Returns empty array if no rows found
 */
export declare function enforceMultiTenantIsolationMany<T extends QueryResultRow = any>(tenantId: string, queryText: string, params?: any[]): Promise<T[]>;
//# sourceMappingURL=multi-tenant-isolation.d.ts.map