/**
 * Example Usage: Multi-Tenant Isolation Middleware
 *
 * This file demonstrates how to use the multi-tenant isolation middleware
 * in repository and service layers.
 *
 * DO NOT import this file in production code - it's for documentation only.
 */
/**
 * Example 1: Repository Layer - League Repository
 *
 * Repositories should use enforceMultiTenantIsolation for all queries
 */
export declare class LeagueRepository {
    /**
     * Find all leagues for a tenant
     */
    findByTenantId(tenantId: string): Promise<any[]>;
    /**
     * Find a specific league by ID
     */
    findById(tenantId: string, leagueId: string): Promise<any>;
    /**
     * Find leagues by sport type
     */
    findBySportType(tenantId: string, sportType: string): Promise<any[]>;
}
/**
 * Example 2: Repository Layer - Game Repository with Complex Filters
 */
export declare class GameRepository {
    /**
     * Find games by season with optional filters
     */
    findBySeasonId(tenantId: string, seasonId: string, filters?: {
        status?: string;
        startDate?: Date;
        endDate?: Date;
        teamId?: string;
    }): Promise<any[]>;
}
/**
 * Example 3: Service Layer - Error Handling
 */
export declare class LeagueService {
    private leagueRepository;
    constructor(leagueRepository: LeagueRepository);
    /**
     * Get leagues with proper error handling
     */
    getLeagues(tenantId: string): Promise<any[]>;
    /**
     * Get league by ID with 404 handling
     */
    getLeagueById(tenantId: string, leagueId: string): Promise<any>;
}
/**
 * Example 4: Lambda Handler - Integration with JWT Validation
 */
export declare function handleGetLeagues(event: any): Promise<{
    statusCode: number;
    body: string;
}>;
/**
 * Example 5: Transaction with Multi-Tenant Isolation
 */
export declare function updateStandingsWithIsolation(tenantId: string, seasonId: string, standings: any[]): Promise<void>;
/**
 * Example 6: Aggregate Queries (no tenant_id in result)
 */
export declare function getLeagueCount(tenantId: string): Promise<number>;
/**
 * Example 7: JOIN Queries with Multiple Tables
 */
export declare function getGamesWithTeams(tenantId: string, seasonId: string): Promise<any[]>;
//# sourceMappingURL=example-usage.d.ts.map