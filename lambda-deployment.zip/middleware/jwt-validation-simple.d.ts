/**
 * Simplified JWT Validation Middleware
 *
 * Validates JWT tokens from Amazon Cognito using manual JWKS fetching.
 * This version uses native https module instead of jwks-rsa library.
 */
import { AuthContext } from '../models/auth';
/**
 * Validate JWT token and extract claims
 */
export declare function validateJWT(authHeader: string | undefined, userPoolId: string, region: string, requestId?: string): Promise<AuthContext>;
export declare function clearPublicKeyCache(): void;
//# sourceMappingURL=jwt-validation-simple.d.ts.map