/**
 * Error Handling Middleware
 *
 * Centralized error handling that catches and formats different types of errors
 * into standardized API responses with appropriate HTTP status codes.
 *
 * Requirements: 8.5, 8.6, 8.7, 8.8
 */
import { APIGatewayProxyResult } from 'aws-lambda';
/**
 * Database error class for connection and query errors
 */
export declare class DatabaseError extends Error {
    originalError?: Error | undefined;
    constructor(message: string, originalError?: Error | undefined);
}
/**
 * Validation error class with optional field-level details
 */
export declare class ValidationError extends Error {
    details?: any | undefined;
    constructor(message: string, details?: any | undefined);
}
/**
 * Authorization error class for permission-related errors
 */
export declare class AuthorizationError extends Error {
    constructor(message: string);
}
/**
 * Check if error is a database connection error
 *
 * Detects common database connection error patterns:
 * - ECONNREFUSED: Connection refused
 * - ETIMEDOUT: Connection timeout
 * - ENOTFOUND: Host not found
 * - Connection terminated unexpectedly
 *
 * @param error - Error to check
 * @returns True if error is a database connection error
 */
export declare function isDatabaseConnectionError(error: Error): boolean;
/**
 * Handle error and format appropriate response
 *
 * Maps application errors to standardized API responses with correct
 * HTTP status codes and error formats. Handles:
 * - Authentication errors (401)
 * - Authorization errors (403)
 * - Not found errors (404)
 * - Validation errors (400)
 * - Database connection errors (503)
 * - Generic errors (500)
 *
 * @param error - Error to handle
 * @param requestId - Request ID for tracing
 * @returns Formatted API Gateway response
 *
 * @example
 * ```typescript
 * try {
 *   // ... operation
 * } catch (error) {
 *   return handleError(error, requestId);
 * }
 * ```
 */
export declare function handleError(error: unknown, requestId: string): APIGatewayProxyResult;
/**
 * Wrap an async function with error handling
 *
 * Provides a higher-order function that automatically catches and handles
 * errors from async operations, converting them to formatted API responses.
 *
 * @param fn - Async function to wrap
 * @param requestId - Request ID for tracing
 * @returns Wrapped function that handles errors
 *
 * @example
 * ```typescript
 * const result = await withErrorHandling(
 *   async () => await service.getData(),
 *   requestId
 * );
 * ```
 */
export declare function withErrorHandling<T>(fn: () => Promise<T>, requestId: string): Promise<T | APIGatewayProxyResult>;
//# sourceMappingURL=error-handler.d.ts.map