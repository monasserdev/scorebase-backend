/**
 * Apply Event to Game Module
 *
 * Updates game state in RDS based on event type using database transactions.
 * Called after event is persisted to DynamoDB to maintain consistency.
 *
 * Requirements: 6.7, 6.8
 */
import { GameEvent } from '../models/event';
/**
 * Apply an event to update game state in RDS
 *
 * Handles different event types:
 * - GOAL_SCORED: Increments appropriate team score
 * - GAME_STARTED: Sets status to 'live'
 * - GAME_FINALIZED: Sets status to 'final' and updates final scores
 * - GAME_CANCELLED: Sets status to 'cancelled'
 *
 * Uses database transactions for atomic updates.
 *
 * @param tenantId - Tenant identifier for validation
 * @param gameId - Game identifier
 * @param event - The event to apply
 * @throws Error if game not found or update fails
 */
export declare function applyEventToGame(tenantId: string, gameId: string, event: GameEvent): Promise<void>;
//# sourceMappingURL=apply-event-to-game.d.ts.map