"use strict";
/**
 * Response Formatting Utilities
 *
 * Provides helper functions for creating standardized API responses.
 * All responses include request_id, timestamp, and CORS headers.
 *
 * Requirements: 8.1, 8.2, 8.3, 8.4, 8.9
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateRequestId = generateRequestId;
exports.generateTimestamp = generateTimestamp;
exports.successResponse = successResponse;
exports.errorResponse = errorResponse;
exports.validationErrorResponse = validationErrorResponse;
exports.authenticationErrorResponse = authenticationErrorResponse;
exports.authorizationErrorResponse = authorizationErrorResponse;
exports.notFoundErrorResponse = notFoundErrorResponse;
exports.internalErrorResponse = internalErrorResponse;
exports.serviceUnavailableErrorResponse = serviceUnavailableErrorResponse;
const uuid_1 = require("uuid");
const response_1 = require("../models/response");
/**
 * CORS headers for all responses
 * Allows cross-origin requests from any origin with credentials
 */
const CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
};
/**
 * Generate a unique request ID
 * Uses UUID v4 for globally unique identifiers
 *
 * @returns UUID v4 string
 */
function generateRequestId() {
    return (0, uuid_1.v4)();
}
/**
 * Generate ISO-8601 timestamp
 * Returns current time in ISO format with timezone
 *
 * @returns ISO-8601 formatted timestamp
 */
function generateTimestamp() {
    return new Date().toISOString();
}
/**
 * Create a success response
 *
 * Wraps response data in standard envelope with request_id and timestamp.
 * Automatically adds CORS headers.
 *
 * @param data - Response payload
 * @param statusCode - HTTP status code (default: 200)
 * @param meta - Optional metadata (e.g., pagination)
 * @param requestId - Optional request ID (generated if not provided)
 * @returns API Gateway response object
 *
 * @example
 * ```typescript
 * return successResponse({ leagues: [...] }, 200);
 * ```
 */
function successResponse(data, statusCode = response_1.HttpStatus.OK, meta, requestId) {
    const response = {
        request_id: requestId || generateRequestId(),
        timestamp: generateTimestamp(),
        data,
    };
    if (meta) {
        response.meta = meta;
    }
    return {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            ...CORS_HEADERS,
        },
        body: JSON.stringify(response),
    };
}
/**
 * Create an error response
 *
 * Wraps error information in standard envelope with request_id and timestamp.
 * Automatically adds CORS headers.
 *
 * @param code - Machine-readable error code
 * @param message - Human-readable error message
 * @param statusCode - HTTP status code
 * @param details - Optional additional error context
 * @param requestId - Optional request ID (generated if not provided)
 * @returns API Gateway response object
 *
 * @example
 * ```typescript
 * return errorResponse(
 *   ErrorCode.NOT_FOUND,
 *   'League not found',
 *   HttpStatus.NOT_FOUND
 * );
 * ```
 */
function errorResponse(code, message, statusCode, details, requestId) {
    const errorDetails = {
        code,
        message,
        request_id: requestId || generateRequestId(),
    };
    if (details) {
        errorDetails.details = details;
    }
    const response = {
        error: errorDetails,
    };
    return {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            ...CORS_HEADERS,
        },
        body: JSON.stringify(response),
    };
}
/**
 * Create a validation error response (400)
 *
 * @param message - Error message
 * @param details - Validation error details
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
function validationErrorResponse(message, details, requestId) {
    return errorResponse(response_1.ErrorCode.VALIDATION_ERROR, message, response_1.HttpStatus.BAD_REQUEST, details, requestId);
}
/**
 * Create an authentication error response (401)
 *
 * @param message - Error message
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
function authenticationErrorResponse(message, requestId) {
    return errorResponse(response_1.ErrorCode.AUTHENTICATION_ERROR, message, response_1.HttpStatus.UNAUTHORIZED, undefined, requestId);
}
/**
 * Create an authorization error response (403)
 *
 * @param message - Error message
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
function authorizationErrorResponse(message, requestId) {
    return errorResponse(response_1.ErrorCode.AUTHORIZATION_ERROR, message, response_1.HttpStatus.FORBIDDEN, undefined, requestId);
}
/**
 * Create a not found error response (404)
 *
 * @param message - Error message
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
function notFoundErrorResponse(message, requestId) {
    return errorResponse(response_1.ErrorCode.NOT_FOUND, message, response_1.HttpStatus.NOT_FOUND, undefined, requestId);
}
/**
 * Create an internal server error response (500)
 *
 * @param message - Error message
 * @param details - Optional error details (sanitized for production)
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
function internalErrorResponse(message = 'Internal server error', details, requestId) {
    return errorResponse(response_1.ErrorCode.INTERNAL_ERROR, message, response_1.HttpStatus.INTERNAL_SERVER_ERROR, details, requestId);
}
/**
 * Create a service unavailable error response (503)
 *
 * @param message - Error message
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
function serviceUnavailableErrorResponse(message = 'Service temporarily unavailable', requestId) {
    return errorResponse(response_1.ErrorCode.SERVICE_UNAVAILABLE, message, response_1.HttpStatus.SERVICE_UNAVAILABLE, undefined, requestId);
}
//# sourceMappingURL=response-formatter.js.map