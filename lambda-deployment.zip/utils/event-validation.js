"use strict";
/**
 * Event Validation Module
 *
 * Validates event payloads against event_type-specific JSON schemas using ajv.
 * Returns 400 Bad Request with field-specific errors for invalid payloads.
 *
 * Requirements: 6.1, 6.6, 8.6, 10.5
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateEventPayload = validateEventPayload;
exports.isValidEventType = isValidEventType;
const ajv_1 = __importDefault(require("ajv"));
const ajv_formats_1 = __importDefault(require("ajv-formats"));
const event_1 = require("../models/event");
const errors_1 = require("../models/errors");
// Initialize ajv with strict mode and format validators
const ajv = new ajv_1.default({
    allErrors: true,
    strict: true,
    coerceTypes: false
});
// Add format validators (date-time, uuid, etc.)
(0, ajv_formats_1.default)(ajv);
const gameStartedSchema = {
    type: 'object',
    properties: {
        start_time: { type: 'string', format: 'date-time' },
        location: { type: 'string', nullable: true }
    },
    required: ['start_time'],
    additionalProperties: false
};
const goalScoredSchema = {
    type: 'object',
    properties: {
        team_id: { type: 'string', format: 'uuid' },
        player_id: { type: 'string', format: 'uuid' },
        assist_player_id: { type: 'string', format: 'uuid', nullable: true },
        period: { type: 'number', minimum: 1 },
        time_remaining: { type: 'string', pattern: '^\\d{2}:\\d{2}$' }
    },
    required: ['team_id', 'player_id', 'period', 'time_remaining'],
    additionalProperties: false
};
const penaltyAssessedSchema = {
    type: 'object',
    properties: {
        team_id: { type: 'string', format: 'uuid' },
        player_id: { type: 'string', format: 'uuid' },
        penalty_type: { type: 'string', minLength: 1 },
        duration_minutes: { type: 'number', minimum: 0 },
        period: { type: 'number', minimum: 1 },
        time_remaining: { type: 'string', pattern: '^\\d{2}:\\d{2}$' }
    },
    required: ['team_id', 'player_id', 'penalty_type', 'duration_minutes', 'period', 'time_remaining'],
    additionalProperties: false
};
const periodEndedSchema = {
    type: 'object',
    properties: {
        period: { type: 'number', minimum: 1 },
        home_score: { type: 'number', minimum: 0 },
        away_score: { type: 'number', minimum: 0 }
    },
    required: ['period', 'home_score', 'away_score'],
    additionalProperties: false
};
const gameFinalizedSchema = {
    type: 'object',
    properties: {
        final_home_score: { type: 'number', minimum: 0 },
        final_away_score: { type: 'number', minimum: 0 }
    },
    required: ['final_home_score', 'final_away_score'],
    additionalProperties: false
};
const gameCancelledSchema = {
    type: 'object',
    properties: {
        reason: { type: 'string', minLength: 1 },
        cancelled_at: { type: 'string', format: 'date-time' }
    },
    required: ['reason', 'cancelled_at'],
    additionalProperties: false
};
const scoreCorrectedSchema = {
    type: 'object',
    properties: {
        team_id: { type: 'string', format: 'uuid' },
        old_score: { type: 'number', minimum: 0 },
        new_score: { type: 'number', minimum: 0 },
        reason: { type: 'string', minLength: 1 }
    },
    required: ['team_id', 'old_score', 'new_score', 'reason'],
    additionalProperties: false
};
// Compile schemas
const validators = {
    [event_1.EventType.GAME_STARTED]: ajv.compile(gameStartedSchema),
    [event_1.EventType.GOAL_SCORED]: ajv.compile(goalScoredSchema),
    [event_1.EventType.PENALTY_ASSESSED]: ajv.compile(penaltyAssessedSchema),
    [event_1.EventType.PERIOD_ENDED]: ajv.compile(periodEndedSchema),
    [event_1.EventType.GAME_FINALIZED]: ajv.compile(gameFinalizedSchema),
    [event_1.EventType.GAME_CANCELLED]: ajv.compile(gameCancelledSchema),
    [event_1.EventType.SCORE_CORRECTED]: ajv.compile(scoreCorrectedSchema)
};
/**
 * Format ajv validation errors into field-specific error details
 */
function formatValidationErrors(errors) {
    const details = {};
    for (const error of errors) {
        const field = error.instancePath ? error.instancePath.substring(1) : error.params.missingProperty || 'payload';
        let message = error.message || 'Validation failed';
        // Enhance error messages based on error type
        if (error.keyword === 'required') {
            message = `Missing required field: ${error.params.missingProperty}`;
        }
        else if (error.keyword === 'type') {
            message = `Expected ${error.params.type}, received ${typeof error.data}`;
        }
        else if (error.keyword === 'format') {
            message = `Invalid format, expected ${error.params.format}`;
        }
        else if (error.keyword === 'pattern') {
            message = `Does not match required pattern`;
        }
        else if (error.keyword === 'minimum') {
            message = `Must be >= ${error.params.limit}`;
        }
        else if (error.keyword === 'minLength') {
            message = `Must be at least ${error.params.limit} characters`;
        }
        else if (error.keyword === 'additionalProperties') {
            message = `Unknown field: ${error.params.additionalProperty}`;
        }
        details[field] = message;
    }
    return details;
}
/**
 * Validate event payload against event_type-specific schema
 *
 * @param event_type - The type of event being validated
 * @param payload - The event payload to validate
 * @throws BadRequestError with field-specific details if validation fails
 */
function validateEventPayload(event_type, payload) {
    // Check if validator exists for this event type
    const validator = validators[event_type];
    if (!validator) {
        throw new errors_1.BadRequestError(`Unknown event type: ${event_type}`);
    }
    // Validate payload
    const valid = validator(payload);
    if (!valid && validator.errors) {
        const details = formatValidationErrors(validator.errors);
        // Create error with field-specific details
        const error = new errors_1.BadRequestError('Invalid event payload');
        error.code = 'INVALID_EVENT_PAYLOAD';
        error.details = details;
        throw error;
    }
}
/**
 * Check if an event type is valid
 */
function isValidEventType(event_type) {
    return Object.values(event_1.EventType).includes(event_type);
}
//# sourceMappingURL=event-validation.js.map