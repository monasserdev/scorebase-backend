"use strict";
/**
 * CloudWatch Metrics Utilities
 *
 * Provides functions to emit custom CloudWatch metrics for monitoring
 * business-specific operations like standings calculations, event writes,
 * and security violations.
 *
 * Requirements: 9.1, 9.2, 9.3, 2.4
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MetricUnit = exports.MetricName = void 0;
exports.emitMetric = emitMetric;
exports.emitStandingsCalculationDuration = emitStandingsCalculationDuration;
exports.emitEventWriteLatency = emitEventWriteLatency;
exports.emitCrossTenantAccessAttempt = emitCrossTenantAccessAttempt;
exports.measureDuration = measureDuration;
const client_cloudwatch_1 = require("@aws-sdk/client-cloudwatch");
/**
 * CloudWatch client instance
 * Reused across Lambda invocations for connection pooling
 */
const cloudWatchClient = new client_cloudwatch_1.CloudWatchClient({
    region: process.env.AWS_REGION || 'us-east-1',
});
/**
 * Namespace for custom metrics
 */
const METRIC_NAMESPACE = 'ScoreBase/Backend';
/**
 * Metric names
 */
var MetricName;
(function (MetricName) {
    MetricName["STANDINGS_CALCULATION_DURATION"] = "StandingsCalculationDuration";
    MetricName["EVENT_WRITE_LATENCY"] = "EventWriteLatency";
    MetricName["CROSS_TENANT_ACCESS_ATTEMPT"] = "CrossTenantAccessAttempt";
})(MetricName || (exports.MetricName = MetricName = {}));
/**
 * Metric units
 */
var MetricUnit;
(function (MetricUnit) {
    MetricUnit["MILLISECONDS"] = "Milliseconds";
    MetricUnit["COUNT"] = "Count";
})(MetricUnit || (exports.MetricUnit = MetricUnit = {}));
/**
 * Emit a custom CloudWatch metric
 *
 * @param metricName - Name of the metric
 * @param value - Metric value
 * @param unit - Metric unit (Milliseconds, Count, etc.)
 * @param dimensions - Optional dimensions for filtering
 */
async function emitMetric(metricName, value, unit, dimensions) {
    try {
        const metricData = {
            MetricName: metricName,
            Value: value,
            Unit: unit,
            Timestamp: new Date(),
        };
        // Add dimensions if provided
        if (dimensions) {
            metricData.Dimensions = Object.entries(dimensions)
                .filter(([_, value]) => value !== undefined)
                .map(([name, value]) => ({
                Name: name,
                Value: value,
            }));
        }
        const command = new client_cloudwatch_1.PutMetricDataCommand({
            Namespace: METRIC_NAMESPACE,
            MetricData: [metricData],
        });
        await cloudWatchClient.send(command);
    }
    catch (error) {
        // Log error but don't throw - metrics should not break application flow
        console.error('Failed to emit CloudWatch metric', {
            metricName,
            value,
            unit,
            dimensions,
            error: error instanceof Error ? error.message : 'Unknown error',
        });
    }
}
/**
 * Emit standings calculation duration metric
 *
 * Tracks how long it takes to recalculate standings for a season.
 * This helps monitor performance and identify slow calculations.
 *
 * @param tenantId - Tenant identifier
 * @param seasonId - Season identifier
 * @param durationMs - Duration in milliseconds
 */
async function emitStandingsCalculationDuration(tenantId, seasonId, durationMs) {
    await emitMetric(MetricName.STANDINGS_CALCULATION_DURATION, durationMs, MetricUnit.MILLISECONDS, {
        tenant_id: tenantId,
        season_id: seasonId,
        operation_type: 'standings_calculation',
    });
}
/**
 * Emit event write latency metric
 *
 * Tracks how long it takes to write an event to DynamoDB.
 * This helps monitor event write performance and identify bottlenecks.
 *
 * @param tenantId - Tenant identifier
 * @param eventType - Type of event being written
 * @param latencyMs - Latency in milliseconds
 */
async function emitEventWriteLatency(tenantId, eventType, latencyMs) {
    await emitMetric(MetricName.EVENT_WRITE_LATENCY, latencyMs, MetricUnit.MILLISECONDS, {
        tenant_id: tenantId,
        event_type: eventType,
        operation_type: 'event_write',
    });
}
/**
 * Emit cross-tenant access attempt metric
 *
 * Tracks security violations where a tenant attempts to access
 * data belonging to another tenant. This is a critical security metric.
 *
 * @param tenantId - Tenant identifier making the request
 * @param violationType - Type of violation (e.g., CROSS_TENANT_DATA_LEAKAGE)
 */
async function emitCrossTenantAccessAttempt(tenantId, violationType) {
    await emitMetric(MetricName.CROSS_TENANT_ACCESS_ATTEMPT, 1, MetricUnit.COUNT, {
        tenant_id: tenantId,
        violation_type: violationType,
        operation_type: 'security_violation',
    });
}
/**
 * Measure and emit duration for an async operation
 *
 * Utility function to measure the duration of an async operation
 * and emit a metric with the result.
 *
 * @param operation - Async operation to measure
 * @param metricName - Name of the metric to emit
 * @param dimensions - Optional dimensions for the metric
 * @returns Result of the operation
 */
async function measureDuration(operation, metricName, dimensions) {
    const startTime = Date.now();
    try {
        const result = await operation();
        const duration = Date.now() - startTime;
        await emitMetric(metricName, duration, MetricUnit.MILLISECONDS, dimensions);
        return result;
    }
    catch (error) {
        const duration = Date.now() - startTime;
        // Emit metric even on error to track failed operation duration
        await emitMetric(metricName, duration, MetricUnit.MILLISECONDS, {
            ...dimensions,
            error: 'true',
        });
        throw error;
    }
}
//# sourceMappingURL=metrics.js.map