/**
 * Structured Logging Module
 *
 * Provides structured JSON logging functions for consistent logging across
 * the application. All logs include request_id, timestamp, and relevant context.
 * Implements PII sanitization to exclude sensitive data.
 *
 * Requirements: 11.1, 11.2, 11.3, 11.4, 11.5, 10.11
 */
/**
 * Log levels
 */
export declare enum LogLevel {
    INFO = "INFO",
    WARN = "WARN",
    ERROR = "ERROR"
}
/**
 * Log API request
 *
 * Logs all API requests with method, path, tenant_id, user_id, status code,
 * and latency. Used for request tracing and performance monitoring.
 *
 * @param params - Request log parameters
 *
 * @example
 * ```typescript
 * logRequest({
 *   requestId: 'abc-123',
 *   method: 'GET',
 *   path: '/v1/leagues',
 *   tenantId: 'tenant-123',
 *   userId: 'user-456',
 *   statusCode: 200,
 *   latencyMs: 45
 * });
 * ```
 */
export declare function logRequest(params: {
    requestId: string;
    method: string;
    path: string;
    tenantId: string;
    userId: string;
    statusCode: number;
    latencyMs: number;
}): void;
/**
 * Log authentication attempt
 *
 * Logs both successful and failed authentication attempts for security
 * monitoring and audit trails.
 *
 * @param params - Authentication log parameters
 *
 * @example
 * ```typescript
 * // Success
 * logAuthentication({
 *   requestId: 'abc-123',
 *   success: true,
 *   tenantId: 'tenant-123',
 *   userId: 'user-456',
 *   username: 'john.doe'
 * });
 *
 * // Failure
 * logAuthentication({
 *   requestId: 'abc-123',
 *   success: false,
 *   reason: 'Token expired'
 * });
 * ```
 */
export declare function logAuthentication(params: {
    requestId: string;
    success: boolean;
    tenantId?: string;
    userId?: string;
    username?: string;
    reason?: string;
}): void;
/**
 * Log authorization check
 *
 * Logs authorization failures with attempted action and resource for
 * security monitoring and debugging permission issues.
 *
 * @param params - Authorization log parameters
 *
 * @example
 * ```typescript
 * logAuthorization({
 *   requestId: 'abc-123',
 *   tenantId: 'tenant-123',
 *   userId: 'user-456',
 *   success: false,
 *   action: 'POST /v1/games/{gameId}/events',
 *   resource: 'game-789',
 *   requiredRole: 'scorekeeper',
 *   userRoles: ['viewer']
 * });
 * ```
 */
export declare function logAuthorization(params: {
    requestId: string;
    tenantId: string;
    userId: string;
    success: boolean;
    action: string;
    resource: string;
    requiredRole?: string;
    userRoles?: string[];
}): void;
/**
 * Log database error
 *
 * Logs database errors with sanitized query preview and error message.
 * Excludes sensitive data and PII from logs.
 *
 * @param params - Database error log parameters
 *
 * @example
 * ```typescript
 * logDatabase({
 *   requestId: 'abc-123',
 *   tenantId: 'tenant-123',
 *   errorMessage: 'Connection timeout',
 *   query: 'SELECT * FROM games WHERE tenant_id = $1',
 *   operation: 'SELECT'
 * });
 * ```
 */
export declare function logDatabase(params: {
    requestId?: string;
    tenantId?: string;
    errorMessage: string;
    query: string;
    operation: string;
}): void;
/**
 * Log security violation
 *
 * Logs security violations with violation type and context for security
 * monitoring and incident response.
 *
 * @param params - Security violation log parameters
 *
 * @example
 * ```typescript
 * logSecurity({
 *   requestId: 'abc-123',
 *   tenantId: 'tenant-123',
 *   userId: 'user-456',
 *   violationType: 'CROSS_TENANT_ACCESS_ATTEMPT',
 *   severity: 'HIGH',
 *   context: {
 *     attempted_tenant_id: 'tenant-789',
 *     resource: 'league-123'
 *   }
 * });
 * ```
 */
export declare function logSecurity(params: {
    requestId?: string;
    tenantId?: string;
    userId?: string;
    violationType: string;
    severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    context: Record<string, any>;
}): void;
/**
 * Log generic message with context
 *
 * General-purpose logging function for custom log entries.
 * Automatically sanitizes context to remove PII.
 *
 * @param level - Log level
 * @param message - Log message
 * @param context - Additional context (will be sanitized)
 *
 * @example
 * ```typescript
 * log(LogLevel.INFO, 'Standings recalculated', {
 *   request_id: 'abc-123',
 *   tenant_id: 'tenant-123',
 *   season_id: 'season-456',
 *   duration_ms: 150
 * });
 * ```
 */
export declare function log(level: LogLevel, message: string, context?: Record<string, any>): void;
//# sourceMappingURL=logger.d.ts.map