/**
 * Standings Calculation Utilities
 *
 * Algorithms for calculating team standings based on game results.
 * Implements the standings recalculation logic that runs when games are finalized.
 *
 * Standings Rules:
 * - Win = 3 points
 * - Tie = 1 point
 * - Loss = 0 points
 * - games_played = wins + losses + ties
 * - goal_differential = goals_for - goals_against
 * - Streak is calculated from recent game results (e.g., "W3", "L2", "T1")
 *
 * Requirements: 7.1, 7.2, 7.3, 7.4, 7.5, 7.6, 7.7, 7.8, 7.10
 */
import { GameRepository } from '../repositories/game-repository';
import { StandingsRepository } from '../repositories/standings-repository';
import { SeasonRepository } from '../repositories/season-repository';
import { TeamRepository } from '../repositories/team-repository';
/**
 * Calculate streak string from recent game results
 *
 * Streak format: Letter + Count (e.g., "W3", "L2", "T1")
 * - W = Win
 * - L = Loss
 * - T = Tie
 *
 * The streak represents consecutive results of the same type,
 * starting from the most recent game.
 *
 * Examples:
 * - ['W', 'W', 'W', 'L'] → "W3"
 * - ['L', 'L', 'W', 'W'] → "L2"
 * - ['T', 'W', 'W'] → "T1"
 * - [] → undefined
 *
 * @param recentResults - Array of recent results, most recent first
 * @returns Streak string or undefined if no results
 */
export declare function calculateStreak(recentResults: ('W' | 'L' | 'T')[]): string | undefined;
/**
 * Recalculate standings for all teams in a season
 *
 * This function:
 * 1. Fetches the season to get the league_id
 * 2. Fetches all teams in the league
 * 3. Fetches all finalized games for the season
 * 4. Initializes standings map for all teams
 * 5. Processes each game to update wins, losses, ties, points, goals
 * 6. Calculates goal differential (goals_for - goals_against)
 * 7. Calculates streaks based on recent game results
 * 8. Persists standings to database using transaction
 *
 * This function is called when a GAME_FINALIZED event is created.
 *
 * @param tenantId - Tenant identifier from JWT claims
 * @param seasonId - Season identifier
 * @param gameRepository - Game repository instance
 * @param standingsRepository - Standings repository instance
 * @param seasonRepository - Season repository instance
 * @param teamRepository - Team repository instance
 * @returns Promise that resolves when standings are recalculated
 */
export declare function recalculateStandings(tenantId: string, seasonId: string, gameRepository: GameRepository, standingsRepository: StandingsRepository, seasonRepository: SeasonRepository, teamRepository: TeamRepository): Promise<void>;
//# sourceMappingURL=standings-calculation.d.ts.map