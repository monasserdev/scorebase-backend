/**
 * Team Repository
 *
 * Data access layer for teams with multi-tenant isolation.
 * All queries enforce tenant_id filtering through league relationships
 * and use parameterized queries to prevent SQL injection.
 *
 * Requirements: 4.1, 4.2
 */
import { Team } from '../models/team';
/**
 * Team Repository
 * Provides data access methods for teams with tenant isolation
 */
export declare class TeamRepository {
    /**
     * Find all teams for a league with tenant validation
     *
     * Joins with leagues table to enforce tenant isolation since
     * teams table has tenant_id but we validate through league relationship.
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param leagueId - League identifier
     * @returns Array of teams belonging to the league
     */
    findByLeagueId(tenantId: string, leagueId: string): Promise<Team[]>;
    /**
     * Find a team by ID with tenant validation
     *
     * Joins with leagues table to enforce tenant isolation.
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param teamId - Team identifier
     * @returns Team if found and belongs to tenant, null otherwise
     */
    findById(tenantId: string, teamId: string): Promise<Team | null>;
}
//# sourceMappingURL=team-repository.d.ts.map