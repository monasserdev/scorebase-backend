/**
 * Standings Repository
 *
 * Data access layer for team standings with multi-tenant isolation.
 * All queries enforce tenant_id filtering through season and league relationships
 * and use parameterized queries to prevent SQL injection.
 *
 * Provides methods for retrieving standings and upserting standings data
 * with transaction support for atomic operations.
 *
 * Requirements: 7.1, 7.9, 7.10
 */
import { TeamStanding, StandingUpsertData } from '../models/standing';
/**
 * Standings Repository
 * Provides data access methods for standings with tenant isolation
 */
export declare class StandingsRepository {
    /**
     * Find all standings for a season with tenant validation
     *
     * Joins with seasons and leagues tables to enforce tenant isolation since
     * standings table doesn't have direct tenant_id column.
     *
     * Results are ordered by:
     * 1. points DESC (primary sort)
     * 2. goal_differential DESC (tiebreaker)
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param seasonId - Season identifier
     * @returns Array of standings ordered by points DESC, goal_differential DESC
     */
    findBySeasonId(tenantId: string, seasonId: string): Promise<TeamStanding[]>;
    /**
     * Upsert standings for multiple teams with transaction support
     *
     * Uses ON CONFLICT (season_id, team_id) DO UPDATE to handle both
     * inserts and updates atomically. All operations are wrapped in a
     * transaction to ensure consistency.
     *
     * This method does NOT enforce tenant isolation directly since it's
     * called from internal services that have already validated tenant access.
     * The unique constraint on (season_id, team_id) prevents cross-tenant
     * data corruption.
     *
     * @param standings - Array of standing data to upsert
     * @returns Promise that resolves when all standings are persisted
     */
    upsertStandings(standings: StandingUpsertData[]): Promise<void>;
}
//# sourceMappingURL=standings-repository.d.ts.map