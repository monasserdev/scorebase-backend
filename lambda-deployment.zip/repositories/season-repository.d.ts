/**
 * Season Repository
 *
 * Data access layer for seasons with multi-tenant isolation.
 * All queries enforce tenant_id filtering through league relationships
 * and use parameterized queries to prevent SQL injection.
 *
 * Requirements: 3.3, 3.4
 */
import { Season } from '../models/season';
/**
 * Season Repository
 * Provides data access methods for seasons with tenant isolation
 */
export declare class SeasonRepository {
    /**
     * Find all seasons for a league with tenant validation
     *
     * Joins with leagues table to enforce tenant isolation since
     * seasons table doesn't have direct tenant_id column.
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param leagueId - League identifier
     * @returns Array of seasons belonging to the league
     */
    findByLeagueId(tenantId: string, leagueId: string): Promise<Season[]>;
    /**
     * Find active seasons for a league with tenant validation
     *
     * Returns only seasons where is_active = true.
     * Joins with leagues table to enforce tenant isolation.
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param leagueId - League identifier
     * @returns Array of active seasons belonging to the league
     */
    findActiveByLeagueId(tenantId: string, leagueId: string): Promise<Season[]>;
    /**
     * Find a season by ID with tenant validation
     *
     * Joins with leagues table to enforce tenant isolation since
     * seasons table doesn't have direct tenant_id column.
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param seasonId - Season identifier
     * @returns Season if found and belongs to tenant, null otherwise
     */
    findById(tenantId: string, seasonId: string): Promise<Season | null>;
}
//# sourceMappingURL=season-repository.d.ts.map