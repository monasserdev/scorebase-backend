"use strict";
/**
 * Environment Configuration
 *
 * Centralized configuration management for environment variables.
 * All configuration values should be accessed through this module.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadEnvironmentConfig = loadEnvironmentConfig;
exports.validateEnvironmentConfig = validateEnvironmentConfig;
/**
 * Load and validate environment configuration
 */
function loadEnvironmentConfig() {
    return {
        dbHost: process.env.DB_HOST || '',
        dbPort: parseInt(process.env.DB_PORT || '5432', 10),
        dbName: process.env.DB_NAME || '',
        dbSecretArn: process.env.DB_SECRET_ARN || '',
        dynamodbTableName: process.env.DYNAMODB_TABLE_NAME || '',
        s3ArchiveBucket: process.env.S3_ARCHIVE_BUCKET || '',
        cognitoUserPoolId: process.env.COGNITO_USER_POOL_ID || '',
        logLevel: process.env.LOG_LEVEL || 'info',
        nodeEnv: process.env.NODE_ENV || 'development',
    };
}
/**
 * Validate that all required environment variables are set
 */
function validateEnvironmentConfig(config) {
    const requiredFields = [
        'dbHost',
        'dbName',
        'dbSecretArn',
        'dynamodbTableName',
        's3ArchiveBucket',
        'cognitoUserPoolId',
    ];
    const missingFields = requiredFields.filter((field) => !config[field]);
    if (missingFields.length > 0) {
        throw new Error(`Missing required environment variables: ${missingFields.join(', ')}`);
    }
}
//# sourceMappingURL=environment.js.map