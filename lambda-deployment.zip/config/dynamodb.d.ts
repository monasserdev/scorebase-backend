/**
 * DynamoDB Client Module
 *
 * Provides DynamoDB client wrapper for event operations.
 * Handles event persistence with TTL calculation and chronological ordering.
 *
 * Requirements: 6.2, 6.3, 6.4, 6.5
 */
import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
import { GameEvent, CreateEventParams, GetEventsParams } from '../models/event';
/**
 * Get or create the DynamoDB DocumentClient
 * Reuses client across Lambda invocations for performance
 */
export declare function getDynamoDBClient(): DynamoDBDocumentClient;
/**
 * Write event to DynamoDB with TTL calculation
 *
 * @param params - Event creation parameters
 * @returns Created event
 */
export declare function writeEvent(params: CreateEventParams): Promise<GameEvent>;
/**
 * Get events by game ID with chronological ordering
 *
 * @param game_id - Game identifier
 * @param tenant_id - Tenant identifier for validation
 * @returns Array of events in chronological order
 */
export declare function getEventsByGame(game_id: string, tenant_id: string): Promise<GameEvent[]>;
/**
 * Get events by tenant ID using GSI
 *
 * @param params - Query parameters
 * @returns Array of events in chronological order
 */
export declare function getEventsByTenant(params: GetEventsParams): Promise<GameEvent[]>;
/**
 * Reset DynamoDB client instance (for testing only)
 * @internal
 */
export declare function resetDynamoDBClient(): void;
//# sourceMappingURL=dynamodb.d.ts.map