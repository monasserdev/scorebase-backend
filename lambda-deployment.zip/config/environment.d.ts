/**
 * Environment Configuration
 *
 * Centralized configuration management for environment variables.
 * All configuration values should be accessed through this module.
 */
export interface EnvironmentConfig {
    dbHost: string;
    dbPort: number;
    dbName: string;
    dbSecretArn: string;
    dynamodbTableName: string;
    s3ArchiveBucket: string;
    cognitoUserPoolId: string;
    logLevel: string;
    nodeEnv: string;
}
/**
 * Load and validate environment configuration
 */
export declare function loadEnvironmentConfig(): EnvironmentConfig;
/**
 * Validate that all required environment variables are set
 */
export declare function validateEnvironmentConfig(config: EnvironmentConfig): void;
//# sourceMappingURL=environment.d.ts.map