/**
 * Database Connection Pool Usage Examples
 *
 * This file demonstrates how to use the database connection pool module
 * for common database operations in the ScoreBase backend.
 */
/**
 * Example 1: Simple parameterized query
 * Always use parameterized queries to prevent SQL injection
 */
export declare function getLeaguesByTenant(tenantId: string): Promise<any[]>;
/**
 * Example 2: Query with multiple parameters
 */
export declare function getGamesBySeasonAndStatus(tenantId: string, seasonId: string, status: string): Promise<any[]>;
/**
 * Example 3: Transaction with multiple operations
 * Use transactions when you need atomic operations
 */
export declare function createGameWithTeams(tenantId: string, gameData: any, homeTeamId: string, awayTeamId: string): Promise<any>;
/**
 * Example 4: Transaction with rollback on error
 * If any operation fails, all changes are rolled back automatically
 */
export declare function updateGameScore(tenantId: string, gameId: string, homeScore: number, awayScore: number): Promise<any>;
/**
 * Example 5: Bulk insert with transaction
 */
export declare function createMultiplePlayers(tenantId: string, teamId: string, players: Array<{
    name: string;
    position: string;
    jerseyNumber: number;
}>): Promise<any[]>;
/**
 * Example 6: Complex query with JOIN
 */
export declare function getStandingsWithTeamInfo(tenantId: string, seasonId: string): Promise<any[]>;
//# sourceMappingURL=database.example.d.ts.map