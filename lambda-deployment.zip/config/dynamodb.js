"use strict";
/**
 * DynamoDB Client Module
 *
 * Provides DynamoDB client wrapper for event operations.
 * Handles event persistence with TTL calculation and chronological ordering.
 *
 * Requirements: 6.2, 6.3, 6.4, 6.5
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDynamoDBClient = getDynamoDBClient;
exports.writeEvent = writeEvent;
exports.getEventsByGame = getEventsByGame;
exports.getEventsByTenant = getEventsByTenant;
exports.resetDynamoDBClient = resetDynamoDBClient;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const uuid_1 = require("uuid");
const environment_1 = require("./environment");
const metrics_1 = require("../utils/metrics");
// Global DynamoDB client instance for Lambda warm starts
let dynamodbClient = null;
/**
 * TTL duration in days for event retention
 */
const EVENT_TTL_DAYS = 90;
/**
 * Event schema version
 */
const EVENT_VERSION = '1.0';
/**
 * Get or create the DynamoDB DocumentClient
 * Reuses client across Lambda invocations for performance
 */
function getDynamoDBClient() {
    if (!dynamodbClient) {
        const client = new client_dynamodb_1.DynamoDBClient({
            region: process.env.AWS_REGION || 'us-east-1',
        });
        // Create DocumentClient with marshalling options
        dynamodbClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client, {
            marshallOptions: {
                removeUndefinedValues: true,
                convertEmptyValues: false,
            },
            unmarshallOptions: {
                wrapNumbers: false,
            },
        });
    }
    return dynamodbClient;
}
/**
 * Calculate TTL timestamp (90 days from now)
 *
 * @returns Unix timestamp for DynamoDB TTL
 */
function calculateTTL() {
    const now = new Date();
    const ttlDate = new Date(now.getTime() + EVENT_TTL_DAYS * 24 * 60 * 60 * 1000);
    return Math.floor(ttlDate.getTime() / 1000);
}
/**
 * Create sort key for chronological ordering
 * Format: occurred_at#event_id
 *
 * @param occurred_at - ISO-8601 timestamp
 * @param event_id - Event UUID
 * @returns Sort key string
 */
function createSortKey(occurred_at, event_id) {
    return `${occurred_at}#${event_id}`;
}
/**
 * Write event to DynamoDB with TTL calculation
 *
 * @param params - Event creation parameters
 * @returns Created event
 */
async function writeEvent(params) {
    const startTime = Date.now();
    const client = getDynamoDBClient();
    const config = (0, environment_1.loadEnvironmentConfig)();
    const event_id = (0, uuid_1.v4)();
    const occurred_at = new Date().toISOString();
    const sort_key = createSortKey(occurred_at, event_id);
    const ttl = calculateTTL();
    const event = {
        event_id,
        game_id: params.game_id,
        tenant_id: params.tenant_id,
        event_type: params.event_type,
        event_version: EVENT_VERSION,
        occurred_at,
        sort_key,
        payload: params.payload,
        metadata: params.metadata,
        ttl,
    };
    try {
        await client.send(new lib_dynamodb_1.PutCommand({
            TableName: config.dynamodbTableName,
            Item: event,
        }));
        // Emit metric for event write latency
        const latency = Date.now() - startTime;
        await (0, metrics_1.emitEventWriteLatency)(params.tenant_id, params.event_type, latency);
        return event;
    }
    catch (error) {
        // Emit metric even on error
        const latency = Date.now() - startTime;
        await (0, metrics_1.emitEventWriteLatency)(params.tenant_id, params.event_type, latency);
        throw error;
    }
}
/**
 * Get events by game ID with chronological ordering
 *
 * @param game_id - Game identifier
 * @param tenant_id - Tenant identifier for validation
 * @returns Array of events in chronological order
 */
async function getEventsByGame(game_id, tenant_id) {
    const client = getDynamoDBClient();
    const config = (0, environment_1.loadEnvironmentConfig)();
    const result = await client.send(new lib_dynamodb_1.QueryCommand({
        TableName: config.dynamodbTableName,
        KeyConditionExpression: 'game_id = :game_id',
        FilterExpression: 'tenant_id = :tenant_id',
        ExpressionAttributeValues: {
            ':game_id': game_id,
            ':tenant_id': tenant_id,
        },
        ScanIndexForward: true, // Chronological order (ascending)
    }));
    return (result.Items || []);
}
/**
 * Get events by tenant ID using GSI
 *
 * @param params - Query parameters
 * @returns Array of events in chronological order
 */
async function getEventsByTenant(params) {
    const client = getDynamoDBClient();
    const config = (0, environment_1.loadEnvironmentConfig)();
    if (!params.tenant_id) {
        throw new Error('tenant_id is required for getEventsByTenant');
    }
    const queryParams = {
        TableName: config.dynamodbTableName,
        IndexName: 'tenant-events-index',
        KeyConditionExpression: 'tenant_id = :tenant_id',
        ExpressionAttributeValues: {
            ':tenant_id': params.tenant_id,
        },
        ScanIndexForward: true, // Chronological order (ascending)
    };
    // Add date range filtering if provided
    if (params.start_date && params.end_date) {
        queryParams.KeyConditionExpression += ' AND sort_key BETWEEN :start_key AND :end_key';
        queryParams.ExpressionAttributeValues[':start_key'] = `${params.start_date}#`;
        queryParams.ExpressionAttributeValues[':end_key'] = `${params.end_date}#\uffff`;
    }
    else if (params.start_date) {
        queryParams.KeyConditionExpression += ' AND sort_key >= :start_key';
        queryParams.ExpressionAttributeValues[':start_key'] = `${params.start_date}#`;
    }
    else if (params.end_date) {
        queryParams.KeyConditionExpression += ' AND sort_key <= :end_key';
        queryParams.ExpressionAttributeValues[':end_key'] = `${params.end_date}#\uffff`;
    }
    // Add limit if provided
    if (params.limit) {
        queryParams.Limit = params.limit;
    }
    const result = await client.send(new lib_dynamodb_1.QueryCommand(queryParams));
    return (result.Items || []);
}
/**
 * Reset DynamoDB client instance (for testing only)
 * @internal
 */
function resetDynamoDBClient() {
    dynamodbClient = null;
}
//# sourceMappingURL=dynamodb.js.map