"use strict";
/**
 * Database Connection Pool Usage Examples
 *
 * This file demonstrates how to use the database connection pool module
 * for common database operations in the ScoreBase backend.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLeaguesByTenant = getLeaguesByTenant;
exports.getGamesBySeasonAndStatus = getGamesBySeasonAndStatus;
exports.createGameWithTeams = createGameWithTeams;
exports.updateGameScore = updateGameScore;
exports.createMultiplePlayers = createMultiplePlayers;
exports.getStandingsWithTeamInfo = getStandingsWithTeamInfo;
const database_1 = require("./database");
/**
 * Example 1: Simple parameterized query
 * Always use parameterized queries to prevent SQL injection
 */
async function getLeaguesByTenant(tenantId) {
    const result = await (0, database_1.query)('SELECT * FROM leagues WHERE tenant_id = $1', [tenantId]);
    return result.rows;
}
/**
 * Example 2: Query with multiple parameters
 */
async function getGamesBySeasonAndStatus(tenantId, seasonId, status) {
    const result = await (0, database_1.query)(`SELECT * FROM games 
     WHERE tenant_id = $1 
     AND season_id = $2 
     AND status = $3
     ORDER BY scheduled_at DESC`, [tenantId, seasonId, status]);
    return result.rows;
}
/**
 * Example 3: Transaction with multiple operations
 * Use transactions when you need atomic operations
 */
async function createGameWithTeams(tenantId, gameData, homeTeamId, awayTeamId) {
    return (0, database_1.transaction)(async (client) => {
        // Insert game
        const gameResult = await client.query(`INSERT INTO games (tenant_id, season_id, home_team_id, away_team_id, scheduled_at, status)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`, [
            tenantId,
            gameData.seasonId,
            homeTeamId,
            awayTeamId,
            gameData.scheduledAt,
            'scheduled',
        ]);
        const game = gameResult.rows[0];
        // Update team statistics
        await client.query(`UPDATE teams 
       SET games_scheduled = games_scheduled + 1
       WHERE tenant_id = $1 AND id IN ($2, $3)`, [tenantId, homeTeamId, awayTeamId]);
        return game;
    });
}
/**
 * Example 4: Transaction with rollback on error
 * If any operation fails, all changes are rolled back automatically
 */
async function updateGameScore(tenantId, gameId, homeScore, awayScore) {
    return (0, database_1.transaction)(async (client) => {
        // Verify game exists and belongs to tenant
        const gameCheck = await client.query('SELECT * FROM games WHERE tenant_id = $1 AND id = $2', [tenantId, gameId]);
        if (gameCheck.rows.length === 0) {
            throw new Error('Game not found');
        }
        const game = gameCheck.rows[0];
        if (game.status === 'final') {
            throw new Error('Cannot update score for finalized game');
        }
        // Update game score
        const result = await client.query(`UPDATE games 
       SET home_score = $1, away_score = $2, status = 'live'
       WHERE tenant_id = $3 AND id = $4
       RETURNING *`, [homeScore, awayScore, tenantId, gameId]);
        return result.rows[0];
    });
}
/**
 * Example 5: Bulk insert with transaction
 */
async function createMultiplePlayers(tenantId, teamId, players) {
    return (0, database_1.transaction)(async (client) => {
        const insertedPlayers = [];
        for (const player of players) {
            const result = await client.query(`INSERT INTO players (tenant_id, team_id, name, position, jersey_number)
         VALUES ($1, $2, $3, $4, $5)
         RETURNING *`, [tenantId, teamId, player.name, player.position, player.jerseyNumber]);
            insertedPlayers.push(result.rows[0]);
        }
        return insertedPlayers;
    });
}
/**
 * Example 6: Complex query with JOIN
 */
async function getStandingsWithTeamInfo(tenantId, seasonId) {
    const result = await (0, database_1.query)(`SELECT 
       s.team_id,
       t.name as team_name,
       t.logo_url,
       s.games_played,
       s.wins,
       s.losses,
       s.ties,
       s.points,
       s.goals_for,
       s.goals_against,
       s.goal_differential,
       s.streak
     FROM standings s
     JOIN teams t ON s.team_id = t.id
     WHERE s.tenant_id = $1 AND s.season_id = $2
     ORDER BY s.points DESC, s.goal_differential DESC`, [tenantId, seasonId]);
    return result.rows;
}
//# sourceMappingURL=database.example.js.map