"use strict";
/**
 * Database Connection Pool Module
 *
 * Provides PostgreSQL connection pooling optimized for AWS Lambda execution.
 * Implements connection reuse across Lambda invocations, parameterized queries,
 * and transaction support for atomic operations.
 *
 * Requirements: 9.4, 10.3
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPool = getPool;
exports.query = query;
exports.transaction = transaction;
exports.closePool = closePool;
exports.resetPool = resetPool;
exports.isPoolHealthy = isPoolHealthy;
const pg_1 = require("pg");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const environment_1 = require("./environment");
const logger_1 = require("../utils/logger");
// Global pool instance for Lambda warm starts
let pool = null;
let cachedCredentials = null;
/**
 * Default pool configuration optimized for Lambda
 */
const DEFAULT_POOL_CONFIG = {
    min: 5,
    max: 20,
    idleTimeoutMillis: 30000, // 30 seconds
    connectionTimeoutMillis: 5000, // 5 seconds
};
/**
 * Fetch database credentials from AWS Secrets Manager
 */
async function getCredentialsFromSecretsManager(secretArn) {
    if (cachedCredentials) {
        return cachedCredentials;
    }
    const client = new client_secrets_manager_1.SecretsManagerClient({ region: process.env.AWS_REGION || 'us-east-1' });
    try {
        const command = new client_secrets_manager_1.GetSecretValueCommand({ SecretId: secretArn });
        const response = await client.send(command);
        if (!response.SecretString) {
            throw new Error('Secret value is empty');
        }
        const secret = JSON.parse(response.SecretString);
        cachedCredentials = {
            username: secret.username,
            password: secret.password,
        };
        return cachedCredentials;
    }
    catch (error) {
        console.error('Failed to fetch database credentials from Secrets Manager:', error);
        throw new Error(`Failed to fetch database credentials: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
}
/**
 * Get or create the database connection pool
 * Reuses pool across Lambda invocations for performance
 */
async function getPool() {
    if (!pool) {
        const config = (0, environment_1.loadEnvironmentConfig)();
        // Fetch credentials from Secrets Manager
        const credentials = await getCredentialsFromSecretsManager(config.dbSecretArn);
        pool = new pg_1.Pool({
            host: config.dbHost,
            port: config.dbPort,
            database: config.dbName,
            user: credentials.username,
            password: credentials.password,
            min: DEFAULT_POOL_CONFIG.min,
            max: DEFAULT_POOL_CONFIG.max,
            idleTimeoutMillis: DEFAULT_POOL_CONFIG.idleTimeoutMillis,
            connectionTimeoutMillis: DEFAULT_POOL_CONFIG.connectionTimeoutMillis,
            ssl: {
                rejectUnauthorized: false, // RDS uses self-signed certificates
            },
        });
        // Handle pool errors
        pool.on('error', (err) => {
            (0, logger_1.logDatabase)({
                errorMessage: err.message,
                query: 'Pool error',
                operation: 'POOL_ERROR',
            });
        });
    }
    return pool;
}
/**
 * Execute a parameterized query
 * Prevents SQL injection by using parameterized queries
 *
 * @param text - SQL query with $1, $2, etc. placeholders
 * @param params - Array of parameter values
 * @returns Query result
 */
async function query(text, params) {
    const pool = await getPool();
    return pool.query(text, params);
}
/**
 * Transaction helper for atomic operations
 * Automatically handles BEGIN, COMMIT, and ROLLBACK
 *
 * @param callback - Function to execute within transaction
 * @returns Result from callback
 */
async function transaction(callback) {
    const pool = await getPool();
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const result = await callback(client);
        await client.query('COMMIT');
        return result;
    }
    catch (error) {
        await client.query('ROLLBACK');
        throw error;
    }
    finally {
        client.release();
    }
}
/**
 * Close the database pool
 * Should be called during Lambda shutdown or testing cleanup
 */
async function closePool() {
    if (pool) {
        await pool.end();
        pool = null;
    }
}
/**
 * Reset pool instance (for testing only)
 * @internal
 */
function resetPool() {
    pool = null;
}
/**
 * Check if pool is healthy
 * Useful for health checks and monitoring
 */
async function isPoolHealthy() {
    try {
        const result = await query('SELECT 1 as health_check');
        return result.rows.length === 1 && result.rows[0].health_check === 1;
    }
    catch (error) {
        console.error('Pool health check failed:', error);
        return false;
    }
}
//# sourceMappingURL=database.js.map