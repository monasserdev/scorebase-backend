"use strict";
/**
 * Main Lambda Handler Entry Point
 *
 * Handles all API Gateway requests with JWT validation, routing,
 * error handling, and structured logging.
 *
 * Requirements: 8.1, 8.2, 11.1
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const jwt_validation_1 = require("../middleware/jwt-validation");
const error_handler_1 = require("../middleware/error-handler");
const errors_1 = require("../models/errors");
const response_formatter_1 = require("../utils/response-formatter");
const response_1 = require("../models/response");
const environment_1 = require("../config/environment");
const logger_1 = require("../utils/logger");
// Import migration runner
const run_migrations_1 = require("../scripts/run-migrations");
// Import services
const league_service_1 = require("../services/league-service");
const season_service_1 = require("../services/season-service");
const team_service_1 = require("../services/team-service");
const player_service_1 = require("../services/player-service");
const game_service_1 = require("../services/game-service");
const event_service_1 = require("../services/event-service");
const standings_service_1 = require("../services/standings-service");
// Import repositories
const league_repository_1 = require("../repositories/league-repository");
const season_repository_1 = require("../repositories/season-repository");
const team_repository_1 = require("../repositories/team-repository");
const player_repository_1 = require("../repositories/player-repository");
const game_repository_1 = require("../repositories/game-repository");
const standings_repository_1 = require("../repositories/standings-repository");
/**
 * Initialize services (singleton pattern for Lambda warm starts)
 */
let services = null;
function getServices() {
    if (!services) {
        // Initialize repositories
        const leagueRepository = new league_repository_1.LeagueRepository();
        const seasonRepository = new season_repository_1.SeasonRepository();
        const teamRepository = new team_repository_1.TeamRepository();
        const playerRepository = new player_repository_1.PlayerRepository();
        const gameRepository = new game_repository_1.GameRepository();
        const standingsRepository = new standings_repository_1.StandingsRepository();
        // Initialize services
        services = {
            leagueService: new league_service_1.LeagueService(leagueRepository),
            seasonService: new season_service_1.SeasonService(seasonRepository),
            teamService: new team_service_1.TeamService(teamRepository),
            playerService: new player_service_1.PlayerService(playerRepository),
            gameService: new game_service_1.GameService(gameRepository),
            eventService: new event_service_1.EventService(gameRepository, seasonRepository, teamRepository, standingsRepository),
            standingsService: new standings_service_1.StandingsService(standingsRepository),
        };
    }
    return services;
}
/**
 * Extract path parameter from event
 */
function getPathParameter(event, name) {
    const value = event.pathParameters?.[name];
    if (!value) {
        throw new errors_1.BadRequestError(`Missing path parameter: ${name}`);
    }
    return value;
}
/**
 * Extract query parameter from event
 */
function getQueryParameter(event, name) {
    return event.queryStringParameters?.[name];
}
/**
 * Parse request body
 */
function parseBody(event) {
    if (!event.body) {
        throw new errors_1.BadRequestError('Request body is required');
    }
    try {
        return JSON.parse(event.body);
    }
    catch (error) {
        throw new errors_1.BadRequestError('Invalid JSON in request body');
    }
}
/**
 * Route handlers
 */
// GET /v1/leagues
async function getLeagues(_event, tenantId, _userId, _roles, requestId) {
    const { leagueService } = getServices();
    const leagues = await leagueService.getLeagues(tenantId);
    return (0, response_formatter_1.successResponse)({ leagues }, response_1.HttpStatus.OK, undefined, requestId);
}
// GET /v1/leagues/{leagueId}
async function getLeagueById(event, tenantId, _userId, _roles, requestId) {
    const { leagueService } = getServices();
    const leagueId = getPathParameter(event, 'leagueId');
    const league = await leagueService.getLeagueById(tenantId, leagueId);
    return (0, response_formatter_1.successResponse)({ league }, response_1.HttpStatus.OK, undefined, requestId);
}
// GET /v1/leagues/{leagueId}/seasons
async function getSeasonsByLeague(event, tenantId, _userId, _roles, requestId) {
    const { seasonService } = getServices();
    const leagueId = getPathParameter(event, 'leagueId');
    const seasons = await seasonService.getSeasonsByLeague(tenantId, leagueId);
    return (0, response_formatter_1.successResponse)({ seasons }, response_1.HttpStatus.OK, undefined, requestId);
}
// GET /v1/seasons/{seasonId}
async function getSeasonById(event, tenantId, _userId, _roles, requestId) {
    const { seasonService } = getServices();
    const seasonId = getPathParameter(event, 'seasonId');
    const season = await seasonService.getSeasonById(tenantId, seasonId);
    return (0, response_formatter_1.successResponse)({ season }, response_1.HttpStatus.OK, undefined, requestId);
}
// GET /v1/seasons/{seasonId}/games
async function getGamesBySeason(event, tenantId, _userId, _roles, requestId) {
    const { gameService } = getServices();
    const seasonId = getPathParameter(event, 'seasonId');
    // Extract optional filters from query parameters
    const filters = {};
    const status = getQueryParameter(event, 'status');
    const startDate = getQueryParameter(event, 'startDate');
    const endDate = getQueryParameter(event, 'endDate');
    const teamId = getQueryParameter(event, 'teamId');
    if (status)
        filters.status = status;
    if (startDate)
        filters.startDate = startDate;
    if (endDate)
        filters.endDate = endDate;
    if (teamId)
        filters.teamId = teamId;
    const games = await gameService.getGamesBySeason(tenantId, seasonId, Object.keys(filters).length > 0 ? filters : undefined);
    return (0, response_formatter_1.successResponse)({ games }, response_1.HttpStatus.OK, undefined, requestId);
}
// GET /v1/seasons/{seasonId}/standings
async function getStandingsBySeason(event, tenantId, _userId, _roles, requestId) {
    const { standingsService } = getServices();
    const seasonId = getPathParameter(event, 'seasonId');
    const standings = await standingsService.getStandingsBySeason(tenantId, seasonId);
    return (0, response_formatter_1.successResponse)({ standings }, response_1.HttpStatus.OK, undefined, requestId);
}
// GET /v1/leagues/{leagueId}/teams
async function getTeamsByLeague(event, tenantId, _userId, _roles, requestId) {
    const { teamService } = getServices();
    const leagueId = getPathParameter(event, 'leagueId');
    const teams = await teamService.getTeamsByLeague(tenantId, leagueId);
    return (0, response_formatter_1.successResponse)({ teams }, response_1.HttpStatus.OK, undefined, requestId);
}
// GET /v1/teams/{teamId}
async function getTeamById(event, tenantId, _userId, _roles, requestId) {
    const { teamService } = getServices();
    const teamId = getPathParameter(event, 'teamId');
    const team = await teamService.getTeamById(tenantId, teamId);
    return (0, response_formatter_1.successResponse)({ team }, response_1.HttpStatus.OK, undefined, requestId);
}
// GET /v1/teams/{teamId}/players
async function getPlayersByTeam(event, tenantId, _userId, _roles, requestId) {
    const { playerService } = getServices();
    const teamId = getPathParameter(event, 'teamId');
    const players = await playerService.getPlayersByTeam(tenantId, teamId);
    return (0, response_formatter_1.successResponse)({ players }, response_1.HttpStatus.OK, undefined, requestId);
}
// GET /v1/players/{playerId}
async function getPlayerById(event, tenantId, _userId, _roles, requestId) {
    const { playerService } = getServices();
    const playerId = getPathParameter(event, 'playerId');
    const player = await playerService.getPlayerById(tenantId, playerId);
    return (0, response_formatter_1.successResponse)({ player }, response_1.HttpStatus.OK, undefined, requestId);
}
// GET /v1/games/{gameId}
async function getGameById(event, tenantId, _userId, _roles, requestId) {
    const { gameService } = getServices();
    const gameId = getPathParameter(event, 'gameId');
    const game = await gameService.getGameById(tenantId, gameId);
    return (0, response_formatter_1.successResponse)({ game }, response_1.HttpStatus.OK, undefined, requestId);
}
// GET /v1/games/{gameId}/events
async function getEventsByGame(event, tenantId, _userId, _roles, requestId) {
    const { eventService } = getServices();
    const gameId = getPathParameter(event, 'gameId');
    const events = await eventService.getEventsByGame(tenantId, gameId);
    return (0, response_formatter_1.successResponse)({ events }, response_1.HttpStatus.OK, undefined, requestId);
}
// POST /v1/games/{gameId}/events
async function createEvent(event, tenantId, userId, _roles, requestId) {
    const { eventService } = getServices();
    const gameId = getPathParameter(event, 'gameId');
    const body = parseBody(event);
    // Validate required fields
    if (!body.event_type) {
        throw new errors_1.BadRequestError('event_type is required');
    }
    if (!body.payload) {
        throw new errors_1.BadRequestError('payload is required');
    }
    // Create event metadata
    const metadata = {
        user_id: userId,
        source: 'api',
        ip_address: event.requestContext?.identity?.sourceIp || 'unknown',
    };
    const createdEvent = await eventService.createEvent(tenantId, gameId, body.event_type, body.payload, metadata);
    return (0, response_formatter_1.successResponse)({ event: createdEvent }, response_1.HttpStatus.CREATED, undefined, requestId);
}
/**
 * Route definitions
 * Note: API Gateway stage is /v1/, so paths received don't include /v1/ prefix
 */
const routes = [
    { method: 'GET', pathPattern: /^\/leagues$/, handler: getLeagues },
    { method: 'GET', pathPattern: /^\/leagues\/[^/]+$/, handler: getLeagueById },
    { method: 'GET', pathPattern: /^\/leagues\/[^/]+\/seasons$/, handler: getSeasonsByLeague },
    { method: 'GET', pathPattern: /^\/seasons\/[^/]+$/, handler: getSeasonById },
    { method: 'GET', pathPattern: /^\/seasons\/[^/]+\/games$/, handler: getGamesBySeason },
    { method: 'GET', pathPattern: /^\/seasons\/[^/]+\/standings$/, handler: getStandingsBySeason },
    { method: 'GET', pathPattern: /^\/leagues\/[^/]+\/teams$/, handler: getTeamsByLeague },
    { method: 'GET', pathPattern: /^\/teams\/[^/]+$/, handler: getTeamById },
    { method: 'GET', pathPattern: /^\/teams\/[^/]+\/players$/, handler: getPlayersByTeam },
    { method: 'GET', pathPattern: /^\/players\/[^/]+$/, handler: getPlayerById },
    { method: 'GET', pathPattern: /^\/games\/[^/]+$/, handler: getGameById },
    { method: 'GET', pathPattern: /^\/games\/[^/]+\/events$/, handler: getEventsByGame },
    { method: 'POST', pathPattern: /^\/games\/[^/]+\/events$/, handler: createEvent, requiredRole: 'scorekeeper' },
];
/**
 * Find matching route for request
 */
function findRoute(method, path) {
    return routes.find(route => route.method === method && route.pathPattern.test(path)) || null;
}
/**
 * Check if user has required role
 */
function hasRequiredRole(userRoles, requiredRole) {
    if (!requiredRole) {
        return true;
    }
    return userRoles.includes(requiredRole);
}
/**
 * Main Lambda handler
 *
 * This handler:
 * 1. Generates a unique request_id for tracing
 * 2. Extracts and validates JWT token from Authorization header
 * 3. Routes requests to appropriate service based on HTTP method and path
 * 4. Handles errors and formats responses
 * 5. Logs all requests to CloudWatch with structured logging
 *
 * @param event - API Gateway proxy event
 * @returns API Gateway proxy result
 */
async function handler(event) {
    const startTime = Date.now();
    const requestId = (0, response_formatter_1.generateRequestId)();
    const method = event.httpMethod;
    const path = event.path;
    try {
        // Handle OPTIONS requests for CORS preflight
        if (method === 'OPTIONS') {
            return (0, response_formatter_1.successResponse)({}, response_1.HttpStatus.OK, undefined, requestId);
        }
        // TEMPORARY: Handle migration endpoint without authentication
        // This must be checked BEFORE JWT validation
        if (method === 'POST' && path === '/admin/migrate') {
            console.log('Running database migrations...');
            const result = await (0, run_migrations_1.runMigrations)();
            const statusCode = result.success ? response_1.HttpStatus.OK : response_1.HttpStatus.INTERNAL_SERVER_ERROR;
            return (0, response_formatter_1.successResponse)(result, statusCode, undefined, requestId);
        }
        // Load environment configuration
        const config = (0, environment_1.loadEnvironmentConfig)();
        const region = process.env.AWS_REGION || 'us-east-1';
        // Extract and validate JWT token
        const authHeader = event.headers?.Authorization || event.headers?.authorization;
        const authContext = await (0, jwt_validation_1.validateJWT)(authHeader, config.cognitoUserPoolId, region, requestId);
        // Find matching route
        const route = findRoute(method, path);
        if (!route) {
            const latencyMs = Date.now() - startTime;
            (0, logger_1.logRequest)({
                requestId,
                method,
                path,
                tenantId: authContext.tenant_id,
                userId: authContext.user_id,
                statusCode: 404,
                latencyMs,
            });
            return (0, response_formatter_1.notFoundErrorResponse)('Route not found', requestId);
        }
        // Check role-based authorization
        if (!hasRequiredRole(authContext.roles, route.requiredRole)) {
            const latencyMs = Date.now() - startTime;
            // Log authorization failure
            (0, logger_1.logAuthorization)({
                requestId,
                tenantId: authContext.tenant_id,
                userId: authContext.user_id,
                success: false,
                action: `${method} ${path}`,
                resource: path,
                requiredRole: route.requiredRole,
                userRoles: authContext.roles,
            });
            (0, logger_1.logRequest)({
                requestId,
                method,
                path,
                tenantId: authContext.tenant_id,
                userId: authContext.user_id,
                statusCode: 403,
                latencyMs,
            });
            return (0, response_formatter_1.authorizationErrorResponse)(`Insufficient permissions. Required role: ${route.requiredRole}`, requestId);
        }
        // Execute route handler
        const result = await route.handler(event, authContext.tenant_id, authContext.user_id, authContext.roles, requestId);
        // Log successful request
        const latencyMs = Date.now() - startTime;
        (0, logger_1.logRequest)({
            requestId,
            method,
            path,
            tenantId: authContext.tenant_id,
            userId: authContext.user_id,
            statusCode: result.statusCode,
            latencyMs,
        });
        return result;
    }
    catch (error) {
        const latencyMs = Date.now() - startTime;
        // Use centralized error handling middleware
        const errorResponse = (0, error_handler_1.handleError)(error, requestId);
        // Log error request (tenant/user may be unknown if auth failed)
        (0, logger_1.logRequest)({
            requestId,
            method,
            path,
            tenantId: 'unknown',
            userId: 'unknown',
            statusCode: errorResponse.statusCode,
            latencyMs,
        });
        return errorResponse;
    }
}
//# sourceMappingURL=api-handler.js.map