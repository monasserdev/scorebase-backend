/**
 * Main Lambda Handler Entry Point
 *
 * Handles all API Gateway requests with JWT validation, routing,
 * error handling, and structured logging.
 *
 * Requirements: 8.1, 8.2, 11.1
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * Main Lambda handler
 *
 * This handler:
 * 1. Generates a unique request_id for tracing
 * 2. Extracts and validates JWT token from Authorization header
 * 3. Routes requests to appropriate service based on HTTP method and path
 * 4. Handles errors and formats responses
 * 5. Logs all requests to CloudWatch with structured logging
 *
 * @param event - API Gateway proxy event
 * @returns API Gateway proxy result
 */
export declare function handler(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
//# sourceMappingURL=api-handler.d.ts.map