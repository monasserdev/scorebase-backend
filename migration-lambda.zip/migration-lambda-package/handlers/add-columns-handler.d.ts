export declare function handler(): Promise<any>;
//# sourceMappingURL=add-columns-handler.d.ts.map