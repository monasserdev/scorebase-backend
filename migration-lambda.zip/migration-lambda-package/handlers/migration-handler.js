"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const run_migrations_1 = require("../scripts/run-migrations");
async function handler() {
    console.log('Migration handler invoked');
    const result = await (0, run_migrations_1.runMigrations)();
    return {
        statusCode: result.success ? 200 : 500,
        body: JSON.stringify(result),
    };
}
//# sourceMappingURL=migration-handler.js.map