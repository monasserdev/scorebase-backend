export declare function handler(): Promise<any>;
//# sourceMappingURL=migration-handler.d.ts.map