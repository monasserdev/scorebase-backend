import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * Lambda handler for serving API documentation
 *
 * This handler serves the Swagger UI and OpenAPI specification files
 * at the /api-docs endpoint.
 */
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=docs-handler.d.ts.map