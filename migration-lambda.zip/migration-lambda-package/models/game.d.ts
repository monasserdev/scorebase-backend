/**
 * Game Models
 *
 * Type definitions for games and related entities.
 * Games represent scheduled matches between teams within a season.
 *
 * Requirements: 5.1, 5.2, 5.3, 5.4, 5.5
 */
/**
 * Game status values
 */
export declare enum GameStatus {
    SCHEDULED = "scheduled",
    LIVE = "live",
    FINAL = "final",
    POSTPONED = "postponed",
    CANCELLED = "cancelled"
}
/**
 * Game entity from database
 */
export interface Game {
    id: string;
    season_id: string;
    home_team_id: string;
    away_team_id: string;
    scheduled_at: Date;
    status: GameStatus;
    home_score: number;
    away_score: number;
    location?: string;
    created_at: Date;
    updated_at: Date;
}
/**
 * Game database row (matches PostgreSQL schema)
 */
export interface GameRow {
    id: string;
    season_id: string;
    home_team_id: string;
    away_team_id: string;
    scheduled_at: Date;
    status: string;
    home_score: number;
    away_score: number;
    location: string | null;
    created_at: Date;
    updated_at: Date;
}
/**
 * Filters for querying games
 */
export interface GameFilters {
    status?: GameStatus;
    startDate?: Date;
    endDate?: Date;
    teamId?: string;
}
/**
 * Convert database row to Game model
 */
export declare function mapGameRow(row: GameRow): Game;
//# sourceMappingURL=game.d.ts.map