"use strict";
/**
 * Game Models
 *
 * Type definitions for games and related entities.
 * Games represent scheduled matches between teams within a season.
 *
 * Requirements: 5.1, 5.2, 5.3, 5.4, 5.5
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GameStatus = void 0;
exports.mapGameRow = mapGameRow;
/**
 * Game status values
 */
var GameStatus;
(function (GameStatus) {
    GameStatus["SCHEDULED"] = "scheduled";
    GameStatus["LIVE"] = "live";
    GameStatus["FINAL"] = "final";
    GameStatus["POSTPONED"] = "postponed";
    GameStatus["CANCELLED"] = "cancelled";
})(GameStatus || (exports.GameStatus = GameStatus = {}));
/**
 * Convert database row to Game model
 */
function mapGameRow(row) {
    return {
        id: row.id,
        season_id: row.season_id,
        home_team_id: row.home_team_id,
        away_team_id: row.away_team_id,
        scheduled_at: row.scheduled_at,
        status: row.status,
        home_score: row.home_score,
        away_score: row.away_score,
        location: row.location || undefined,
        created_at: row.created_at,
        updated_at: row.updated_at,
    };
}
//# sourceMappingURL=game.js.map