/**
 * Player Models
 *
 * Type definitions for players and related entities.
 * Players represent individual athletes on teams.
 *
 * Requirements: 4.3, 4.4
 */
/**
 * Player entity from database
 */
export interface Player {
    id: string;
    team_id: string;
    first_name: string;
    last_name: string;
    jersey_number?: string;
    position?: string;
    created_at: Date;
    updated_at: Date;
}
/**
 * Player database row (matches PostgreSQL schema)
 */
export interface PlayerRow {
    id: string;
    team_id: string;
    first_name: string;
    last_name: string;
    jersey_number: string | null;
    position: string | null;
    created_at: Date;
    updated_at: Date;
}
/**
 * Convert database row to Player model
 */
export declare function mapPlayerRow(row: PlayerRow): Player;
//# sourceMappingURL=player.d.ts.map