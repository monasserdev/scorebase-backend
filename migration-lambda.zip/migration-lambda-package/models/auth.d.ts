/**
 * Authentication Models
 *
 * Type definitions for JWT tokens and authentication context.
 *
 * Requirements: 1.1, 1.2, 1.3, 1.4
 */
/**
 * JWT token claims from Cognito
 */
export interface JWTClaims {
    sub: string;
    email?: string;
    'cognito:username': string;
    'cognito:groups'?: string[];
    'custom:tenant_id': string;
    iss: string;
    aud: string;
    token_use: string;
    auth_time: number;
    exp: number;
    iat: number;
}
/**
 * Authenticated user context extracted from JWT
 */
export interface AuthContext {
    user_id: string;
    tenant_id: string;
    roles: string[];
    username: string;
    email?: string;
}
/**
 * Authentication error types
 */
export declare enum AuthErrorCode {
    MISSING_TOKEN = "MISSING_TOKEN",
    INVALID_TOKEN = "INVALID_TOKEN",
    EXPIRED_TOKEN = "EXPIRED_TOKEN",
    INVALID_SIGNATURE = "INVALID_SIGNATURE",
    MISSING_TENANT_ID = "MISSING_TENANT_ID"
}
/**
 * Authentication error
 */
export declare class AuthError extends Error {
    code: AuthErrorCode;
    constructor(code: AuthErrorCode, message: string);
}
//# sourceMappingURL=auth.d.ts.map