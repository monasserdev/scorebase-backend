"use strict";
/**
 * League Models
 *
 * Type definitions for leagues and related entities.
 * Leagues represent sport competitions within a tenant.
 *
 * Requirements: 3.1, 3.2
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SportType = void 0;
exports.mapLeagueRow = mapLeagueRow;
/**
 * Supported sport types
 */
var SportType;
(function (SportType) {
    SportType["BASKETBALL"] = "basketball";
    SportType["SOCCER"] = "soccer";
    SportType["HOCKEY"] = "hockey";
    SportType["BASEBALL"] = "baseball";
    SportType["FOOTBALL"] = "football";
})(SportType || (exports.SportType = SportType = {}));
/**
 * Convert database row to League model
 */
function mapLeagueRow(row) {
    return {
        id: row.id,
        tenant_id: row.tenant_id,
        name: row.name,
        sport_type: row.sport_type,
        logo_url: row.logo_url || undefined,
        primary_color: row.primary_color || undefined,
        secondary_color: row.secondary_color || undefined,
        created_at: row.created_at,
        updated_at: row.updated_at,
    };
}
//# sourceMappingURL=league.js.map