"use strict";
/**
 * Event Models
 *
 * Type definitions for game events stored in DynamoDB.
 * Events are immutable and provide an audit trail of all game actions.
 *
 * Requirements: 6.1, 6.2, 6.3, 6.4, 6.5
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventType = void 0;
/**
 * Supported event types for game actions
 */
var EventType;
(function (EventType) {
    EventType["GAME_STARTED"] = "GAME_STARTED";
    EventType["GOAL_SCORED"] = "GOAL_SCORED";
    EventType["PENALTY_ASSESSED"] = "PENALTY_ASSESSED";
    EventType["PERIOD_ENDED"] = "PERIOD_ENDED";
    EventType["GAME_FINALIZED"] = "GAME_FINALIZED";
    EventType["GAME_CANCELLED"] = "GAME_CANCELLED";
    EventType["SCORE_CORRECTED"] = "SCORE_CORRECTED";
})(EventType || (exports.EventType = EventType = {}));
//# sourceMappingURL=event.js.map