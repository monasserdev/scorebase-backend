/**
 * Player Repository
 *
 * Data access layer for players with multi-tenant isolation.
 * All queries enforce tenant_id filtering through team and league relationships
 * and use parameterized queries to prevent SQL injection.
 *
 * Requirements: 4.3, 4.4
 */
import { Player } from '../models/player';
/**
 * Player Repository
 * Provides data access methods for players with tenant isolation
 */
export declare class PlayerRepository {
    /**
     * Find all players for a team with tenant validation
     *
     * Joins with teams and leagues tables to enforce tenant isolation since
     * players table doesn't have tenant_id but we validate through team->league relationship.
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param teamId - Team identifier
     * @returns Array of players belonging to the team
     */
    findByTeamId(tenantId: string, teamId: string): Promise<Player[]>;
    /**
     * Find a player by ID with tenant validation
     *
     * Joins with teams and leagues tables to enforce tenant isolation.
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param playerId - Player identifier
     * @returns Player if found and belongs to tenant, null otherwise
     */
    findById(tenantId: string, playerId: string): Promise<Player | null>;
}
//# sourceMappingURL=player-repository.d.ts.map