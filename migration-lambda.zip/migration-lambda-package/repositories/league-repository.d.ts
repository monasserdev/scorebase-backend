/**
 * League Repository
 *
 * Data access layer for leagues with multi-tenant isolation.
 * All queries enforce tenant_id filtering and use parameterized queries
 * to prevent SQL injection.
 *
 * Requirements: 3.1, 3.2, 10.3
 */
import { League } from '../models/league';
/**
 * League Repository
 * Provides data access methods for leagues with tenant isolation
 */
export declare class LeagueRepository {
    /**
     * Find all leagues for a tenant
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @returns Array of leagues belonging to the tenant
     */
    findByTenantId(tenantId: string): Promise<League[]>;
    /**
     * Find a league by ID with tenant validation
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param leagueId - League identifier
     * @returns League if found and belongs to tenant, null otherwise
     */
    findById(tenantId: string, leagueId: string): Promise<League | null>;
}
//# sourceMappingURL=league-repository.d.ts.map