/**
 * Game Repository
 *
 * Data access layer for games with multi-tenant isolation.
 * All queries enforce tenant_id filtering through season and league relationships
 * and use parameterized queries to prevent SQL injection.
 *
 * Requirements: 5.1, 5.2, 5.3, 5.4, 5.5
 */
import { Game, GameFilters } from '../models/game';
/**
 * Game Repository
 * Provides data access methods for games with tenant isolation
 */
export declare class GameRepository {
    /**
     * Find all games for a season with optional filters and tenant validation
     *
     * Joins with seasons and leagues tables to enforce tenant isolation since
     * games table doesn't have direct tenant_id column.
     *
     * Supports filtering by:
     * - status: Filter by game status (scheduled, live, final, postponed, cancelled)
     * - startDate/endDate: Filter by scheduled_at date range
     * - teamId: Filter by team (home or away)
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param seasonId - Season identifier
     * @param filters - Optional filters for status, date range, and team
     * @returns Array of games belonging to the season
     */
    findBySeasonId(tenantId: string, seasonId: string, filters?: GameFilters): Promise<Game[]>;
    /**
     * Find a game by ID with tenant validation
     *
     * Joins with seasons and leagues tables to enforce tenant isolation since
     * games table doesn't have direct tenant_id column.
     *
     * @param tenantId - Tenant identifier from JWT claims
     * @param gameId - Game identifier
     * @returns Game if found and belongs to tenant, null otherwise
     */
    findById(tenantId: string, gameId: string): Promise<Game | null>;
}
//# sourceMappingURL=game-repository.d.ts.map