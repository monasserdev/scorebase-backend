/**
 * Database Connection Pool Module
 *
 * Provides PostgreSQL connection pooling optimized for AWS Lambda execution.
 * Implements connection reuse across Lambda invocations, parameterized queries,
 * and transaction support for atomic operations.
 *
 * Requirements: 9.4, 10.3
 */
import { Pool, PoolClient, QueryResult, QueryResultRow } from 'pg';
/**
 * Get or create the database connection pool
 * Reuses pool across Lambda invocations for performance
 */
export declare function getPool(): Promise<Pool>;
/**
 * Execute a parameterized query
 * Prevents SQL injection by using parameterized queries
 *
 * @param text - SQL query with $1, $2, etc. placeholders
 * @param params - Array of parameter values
 * @returns Query result
 */
export declare function query<T extends QueryResultRow = any>(text: string, params?: any[]): Promise<QueryResult<T>>;
/**
 * Transaction helper for atomic operations
 * Automatically handles BEGIN, COMMIT, and ROLLBACK
 *
 * @param callback - Function to execute within transaction
 * @returns Result from callback
 */
export declare function transaction<T>(callback: (client: PoolClient) => Promise<T>): Promise<T>;
/**
 * Close the database pool
 * Should be called during Lambda shutdown or testing cleanup
 */
export declare function closePool(): Promise<void>;
/**
 * Reset pool instance (for testing only)
 * @internal
 */
export declare function resetPool(): void;
/**
 * Check if pool is healthy
 * Useful for health checks and monitoring
 */
export declare function isPoolHealthy(): Promise<boolean>;
//# sourceMappingURL=database.d.ts.map