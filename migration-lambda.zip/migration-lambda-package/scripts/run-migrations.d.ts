/**
 * Database Migration Runner
 *
 * This script runs database migrations using node-pg-migrate.
 * Can be invoked as a Lambda function or run locally.
 */
interface MigrationResult {
    success: boolean;
    message: string;
    error?: string;
}
/**
 * Run database migrations
 */
export declare function runMigrations(): Promise<MigrationResult>;
/**
 * Lambda handler for running migrations
 */
export declare function handler(): Promise<any>;
export {};
//# sourceMappingURL=run-migrations.d.ts.map