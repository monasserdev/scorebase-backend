/**
 * ScoreBase Backend API
 *
 * Main entry point for the Lambda function.
 * This file will be implemented in later tasks.
 */
export * from './config/environment';
export * from './config/database';
export * from './config/dynamodb';
export * from './models/event';
export declare function handler(_event: unknown): Promise<unknown>;
//# sourceMappingURL=index.d.ts.map