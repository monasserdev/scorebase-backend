/**
 * Event Validation Module
 *
 * Validates event payloads against event_type-specific JSON schemas using ajv.
 * Returns 400 Bad Request with field-specific errors for invalid payloads.
 *
 * Requirements: 6.1, 6.6, 8.6, 10.5
 */
import { EventType, EventPayload } from '../models/event';
/**
 * Validate event payload against event_type-specific schema
 *
 * @param event_type - The type of event being validated
 * @param payload - The event payload to validate
 * @throws BadRequestError with field-specific details if validation fails
 */
export declare function validateEventPayload(event_type: EventType, payload: EventPayload): void;
/**
 * Check if an event type is valid
 */
export declare function isValidEventType(event_type: string): event_type is EventType;
//# sourceMappingURL=event-validation.d.ts.map