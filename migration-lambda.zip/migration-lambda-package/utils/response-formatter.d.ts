/**
 * Response Formatting Utilities
 *
 * Provides helper functions for creating standardized API responses.
 * All responses include request_id, timestamp, and CORS headers.
 *
 * Requirements: 8.1, 8.2, 8.3, 8.4, 8.9
 */
import { ResponseMeta, HttpStatus } from '../models/response';
/**
 * Generate a unique request ID
 * Uses UUID v4 for globally unique identifiers
 *
 * @returns UUID v4 string
 */
export declare function generateRequestId(): string;
/**
 * Generate ISO-8601 timestamp
 * Returns current time in ISO format with timezone
 *
 * @returns ISO-8601 formatted timestamp
 */
export declare function generateTimestamp(): string;
/**
 * Create a success response
 *
 * Wraps response data in standard envelope with request_id and timestamp.
 * Automatically adds CORS headers.
 *
 * @param data - Response payload
 * @param statusCode - HTTP status code (default: 200)
 * @param meta - Optional metadata (e.g., pagination)
 * @param requestId - Optional request ID (generated if not provided)
 * @returns API Gateway response object
 *
 * @example
 * ```typescript
 * return successResponse({ leagues: [...] }, 200);
 * ```
 */
export declare function successResponse<T = any>(data: T, statusCode?: HttpStatus, meta?: ResponseMeta, requestId?: string): {
    statusCode: HttpStatus;
    headers: {
        'Access-Control-Allow-Origin': string;
        'Access-Control-Allow-Credentials': string;
        'Access-Control-Allow-Headers': string;
        'Access-Control-Allow-Methods': string;
        'Content-Type': string;
    };
    body: string;
};
/**
 * Create an error response
 *
 * Wraps error information in standard envelope with request_id and timestamp.
 * Automatically adds CORS headers.
 *
 * @param code - Machine-readable error code
 * @param message - Human-readable error message
 * @param statusCode - HTTP status code
 * @param details - Optional additional error context
 * @param requestId - Optional request ID (generated if not provided)
 * @returns API Gateway response object
 *
 * @example
 * ```typescript
 * return errorResponse(
 *   ErrorCode.NOT_FOUND,
 *   'League not found',
 *   HttpStatus.NOT_FOUND
 * );
 * ```
 */
export declare function errorResponse(code: string, message: string, statusCode: HttpStatus, details?: any, requestId?: string): {
    statusCode: HttpStatus;
    headers: {
        'Access-Control-Allow-Origin': string;
        'Access-Control-Allow-Credentials': string;
        'Access-Control-Allow-Headers': string;
        'Access-Control-Allow-Methods': string;
        'Content-Type': string;
    };
    body: string;
};
/**
 * Create a validation error response (400)
 *
 * @param message - Error message
 * @param details - Validation error details
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
export declare function validationErrorResponse(message: string, details?: any, requestId?: string): {
    statusCode: HttpStatus;
    headers: {
        'Access-Control-Allow-Origin': string;
        'Access-Control-Allow-Credentials': string;
        'Access-Control-Allow-Headers': string;
        'Access-Control-Allow-Methods': string;
        'Content-Type': string;
    };
    body: string;
};
/**
 * Create an authentication error response (401)
 *
 * @param message - Error message
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
export declare function authenticationErrorResponse(message: string, requestId?: string): {
    statusCode: HttpStatus;
    headers: {
        'Access-Control-Allow-Origin': string;
        'Access-Control-Allow-Credentials': string;
        'Access-Control-Allow-Headers': string;
        'Access-Control-Allow-Methods': string;
        'Content-Type': string;
    };
    body: string;
};
/**
 * Create an authorization error response (403)
 *
 * @param message - Error message
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
export declare function authorizationErrorResponse(message: string, requestId?: string): {
    statusCode: HttpStatus;
    headers: {
        'Access-Control-Allow-Origin': string;
        'Access-Control-Allow-Credentials': string;
        'Access-Control-Allow-Headers': string;
        'Access-Control-Allow-Methods': string;
        'Content-Type': string;
    };
    body: string;
};
/**
 * Create a not found error response (404)
 *
 * @param message - Error message
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
export declare function notFoundErrorResponse(message: string, requestId?: string): {
    statusCode: HttpStatus;
    headers: {
        'Access-Control-Allow-Origin': string;
        'Access-Control-Allow-Credentials': string;
        'Access-Control-Allow-Headers': string;
        'Access-Control-Allow-Methods': string;
        'Content-Type': string;
    };
    body: string;
};
/**
 * Create an internal server error response (500)
 *
 * @param message - Error message
 * @param details - Optional error details (sanitized for production)
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
export declare function internalErrorResponse(message?: string, details?: any, requestId?: string): {
    statusCode: HttpStatus;
    headers: {
        'Access-Control-Allow-Origin': string;
        'Access-Control-Allow-Credentials': string;
        'Access-Control-Allow-Headers': string;
        'Access-Control-Allow-Methods': string;
        'Content-Type': string;
    };
    body: string;
};
/**
 * Create a service unavailable error response (503)
 *
 * @param message - Error message
 * @param requestId - Optional request ID
 * @returns API Gateway response object
 */
export declare function serviceUnavailableErrorResponse(message?: string, requestId?: string): {
    statusCode: HttpStatus;
    headers: {
        'Access-Control-Allow-Origin': string;
        'Access-Control-Allow-Credentials': string;
        'Access-Control-Allow-Headers': string;
        'Access-Control-Allow-Methods': string;
        'Content-Type': string;
    };
    body: string;
};
//# sourceMappingURL=response-formatter.d.ts.map