"use strict";
/**
 * Apply Event to Game Module
 *
 * Updates game state in RDS based on event type using database transactions.
 * Called after event is persisted to DynamoDB to maintain consistency.
 *
 * Requirements: 6.7, 6.8
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.applyEventToGame = applyEventToGame;
const database_1 = require("../config/database");
const event_1 = require("../models/event");
const game_1 = require("../models/game");
const errors_1 = require("../models/errors");
/**
 * Apply an event to update game state in RDS
 *
 * Handles different event types:
 * - GOAL_SCORED: Increments appropriate team score
 * - GAME_STARTED: Sets status to 'live'
 * - GAME_FINALIZED: Sets status to 'final' and updates final scores
 * - GAME_CANCELLED: Sets status to 'cancelled'
 *
 * Uses database transactions for atomic updates.
 *
 * @param tenantId - Tenant identifier for validation
 * @param gameId - Game identifier
 * @param event - The event to apply
 * @throws Error if game not found or update fails
 */
async function applyEventToGame(tenantId, gameId, event) {
    await (0, database_1.transaction)(async (client) => {
        // Verify game exists and belongs to tenant
        const gameCheck = await client.query(`SELECT g.id, g.status, g.home_team_id, g.away_team_id, g.home_score, g.away_score
       FROM games g
       INNER JOIN seasons s ON g.season_id = s.id
       INNER JOIN leagues l ON s.league_id = l.id
       WHERE l.tenant_id = $1 AND g.id = $2`, [tenantId, gameId]);
        if (gameCheck.rows.length === 0) {
            throw new errors_1.NotFoundError(`Game not found: ${gameId}`);
        }
        const game = gameCheck.rows[0];
        // Apply event based on type
        switch (event.event_type) {
            case event_1.EventType.GOAL_SCORED:
                await handleGoalScored(client, gameId, game, event);
                break;
            case event_1.EventType.GAME_STARTED:
                await handleGameStarted(client, gameId);
                break;
            case event_1.EventType.GAME_FINALIZED:
                await handleGameFinalized(client, gameId, event);
                break;
            case event_1.EventType.GAME_CANCELLED:
                await handleGameCancelled(client, gameId);
                break;
            // Other event types don't modify game state
            case event_1.EventType.PENALTY_ASSESSED:
            case event_1.EventType.PERIOD_ENDED:
            case event_1.EventType.SCORE_CORRECTED:
                // No game state changes needed
                break;
            default:
                // Unknown event type - log but don't fail
                console.warn(`Unknown event type: ${event.event_type}`);
        }
    });
}
/**
 * Handle GOAL_SCORED event - increment appropriate team score
 */
async function handleGoalScored(client, gameId, game, event) {
    const { team_id } = event.payload;
    // Determine which score to increment
    let updateQuery;
    if (team_id === game.home_team_id) {
        updateQuery = `
      UPDATE games
      SET home_score = home_score + 1,
          updated_at = NOW()
      WHERE id = $1
    `;
    }
    else if (team_id === game.away_team_id) {
        updateQuery = `
      UPDATE games
      SET away_score = away_score + 1,
          updated_at = NOW()
      WHERE id = $1
    `;
    }
    else {
        throw new errors_1.BadRequestError(`Team ${team_id} is not part of game ${gameId}`);
    }
    await client.query(updateQuery, [gameId]);
}
/**
 * Handle GAME_STARTED event - set status to 'live'
 */
async function handleGameStarted(client, gameId) {
    await client.query(`UPDATE games
     SET status = $1,
         updated_at = NOW()
     WHERE id = $2`, [game_1.GameStatus.LIVE, gameId]);
}
/**
 * Handle GAME_FINALIZED event - set status to 'final' and update final scores
 */
async function handleGameFinalized(client, gameId, event) {
    const { final_home_score, final_away_score } = event.payload;
    await client.query(`UPDATE games
     SET status = $1,
         home_score = $2,
         away_score = $3,
         updated_at = NOW()
     WHERE id = $4`, [game_1.GameStatus.FINAL, final_home_score, final_away_score, gameId]);
}
/**
 * Handle GAME_CANCELLED event - set status to 'cancelled'
 */
async function handleGameCancelled(client, gameId) {
    await client.query(`UPDATE games
     SET status = $1,
         updated_at = NOW()
     WHERE id = $2`, [game_1.GameStatus.CANCELLED, gameId]);
}
//# sourceMappingURL=apply-event-to-game.js.map