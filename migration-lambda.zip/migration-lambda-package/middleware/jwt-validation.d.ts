/**
 * JWT Validation Middleware
 *
 * Validates JWT tokens from Amazon Cognito and extracts user context.
 * Implements public key caching for performance optimization.
 *
 * Requirements: 1.1, 1.2, 1.3, 1.4, 10.2
 */
import { AuthContext } from '../models/auth';
/**
 * Validate JWT token and extract claims
 *
 * This function:
 * 1. Extracts the token from the Authorization header
 * 2. Decodes the token header to get the key ID (kid)
 * 3. Fetches the public key from Cognito (with caching)
 * 4. Verifies the token signature and expiration
 * 5. Extracts and validates claims
 *
 * @param authHeader - Authorization header value (Bearer <token>)
 * @param userPoolId - Cognito User Pool ID
 * @param region - AWS region
 * @param requestId - Optional request ID for logging
 * @returns Authenticated user context
 * @throws AuthError for invalid, expired, or malformed tokens
 */
export declare function validateJWT(authHeader: string | undefined, userPoolId: string, region: string, requestId?: string): Promise<AuthContext>;
/**
 * Clear the public key cache
 * Useful for testing or forcing key refresh
 */
export declare function clearPublicKeyCache(): void;
//# sourceMappingURL=jwt-validation.d.ts.map