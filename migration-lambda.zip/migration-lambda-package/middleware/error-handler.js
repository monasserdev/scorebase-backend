"use strict";
/**
 * Error Handling Middleware
 *
 * Centralized error handling that catches and formats different types of errors
 * into standardized API responses with appropriate HTTP status codes.
 *
 * Requirements: 8.5, 8.6, 8.7, 8.8
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthorizationError = exports.ValidationError = exports.DatabaseError = void 0;
exports.isDatabaseConnectionError = isDatabaseConnectionError;
exports.handleError = handleError;
exports.withErrorHandling = withErrorHandling;
const auth_1 = require("../models/auth");
const errors_1 = require("../models/errors");
const response_formatter_1 = require("../utils/response-formatter");
/**
 * Database error class for connection and query errors
 */
class DatabaseError extends Error {
    constructor(message, originalError) {
        super(message);
        this.originalError = originalError;
        this.name = 'DatabaseError';
    }
}
exports.DatabaseError = DatabaseError;
/**
 * Validation error class with optional field-level details
 */
class ValidationError extends Error {
    constructor(message, details) {
        super(message);
        this.details = details;
        this.name = 'ValidationError';
    }
}
exports.ValidationError = ValidationError;
/**
 * Authorization error class for permission-related errors
 */
class AuthorizationError extends Error {
    constructor(message) {
        super(message);
        this.name = 'AuthorizationError';
    }
}
exports.AuthorizationError = AuthorizationError;
/**
 * Check if error is a database connection error
 *
 * Detects common database connection error patterns:
 * - ECONNREFUSED: Connection refused
 * - ETIMEDOUT: Connection timeout
 * - ENOTFOUND: Host not found
 * - Connection terminated unexpectedly
 *
 * @param error - Error to check
 * @returns True if error is a database connection error
 */
function isDatabaseConnectionError(error) {
    const message = error.message.toLowerCase();
    return (message.includes('econnrefused') ||
        message.includes('etimedout') ||
        message.includes('enotfound') ||
        message.includes('connection terminated') ||
        message.includes('connection refused') ||
        message.includes('connect timeout') ||
        error.name === 'DatabaseError');
}
/**
 * Handle error and format appropriate response
 *
 * Maps application errors to standardized API responses with correct
 * HTTP status codes and error formats. Handles:
 * - Authentication errors (401)
 * - Authorization errors (403)
 * - Not found errors (404)
 * - Validation errors (400)
 * - Database connection errors (503)
 * - Generic errors (500)
 *
 * @param error - Error to handle
 * @param requestId - Request ID for tracing
 * @returns Formatted API Gateway response
 *
 * @example
 * ```typescript
 * try {
 *   // ... operation
 * } catch (error) {
 *   return handleError(error, requestId);
 * }
 * ```
 */
function handleError(error, requestId) {
    // Ensure error is an Error object
    const err = error instanceof Error ? error : new Error(String(error));
    // Handle authentication errors (401)
    if (err instanceof auth_1.AuthError) {
        return (0, response_formatter_1.authenticationErrorResponse)(err.message, requestId);
    }
    // Handle authorization errors (403)
    if (err instanceof errors_1.ForbiddenError || err instanceof AuthorizationError) {
        return (0, response_formatter_1.authorizationErrorResponse)(err.message, requestId);
    }
    // Handle not found errors (404)
    if (err instanceof errors_1.NotFoundError) {
        return (0, response_formatter_1.notFoundErrorResponse)(err.message, requestId);
    }
    // Handle validation errors (400)
    if (err instanceof errors_1.BadRequestError || err instanceof ValidationError) {
        const details = err.details;
        return (0, response_formatter_1.validationErrorResponse)(err.message, details, requestId);
    }
    // Handle database connection errors (503)
    if (err instanceof errors_1.ServiceUnavailableError || isDatabaseConnectionError(err)) {
        const message = err instanceof errors_1.ServiceUnavailableError
            ? err.message
            : 'Database connection failed';
        return (0, response_formatter_1.serviceUnavailableErrorResponse)(message, requestId);
    }
    // Handle generic errors (500)
    console.error('Unhandled error:', err);
    return (0, response_formatter_1.internalErrorResponse)('Internal server error', process.env.NODE_ENV === 'development' ? { error: err.message } : undefined, requestId);
}
/**
 * Wrap an async function with error handling
 *
 * Provides a higher-order function that automatically catches and handles
 * errors from async operations, converting them to formatted API responses.
 *
 * @param fn - Async function to wrap
 * @param requestId - Request ID for tracing
 * @returns Wrapped function that handles errors
 *
 * @example
 * ```typescript
 * const result = await withErrorHandling(
 *   async () => await service.getData(),
 *   requestId
 * );
 * ```
 */
async function withErrorHandling(fn, requestId) {
    try {
        return await fn();
    }
    catch (error) {
        return handleError(error, requestId);
    }
}
//# sourceMappingURL=error-handler.js.map